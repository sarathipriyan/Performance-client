﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.Repo
{
    public class GeneralRepository : IGeneralRepository
    {
        public readonly Delivery_way2Context _context;
        public GeneralRepository(Delivery_way2Context context)
        {
            _context = context;
        }
        public List<Energy> GetEnergyByFilters(List<string> powersupplyIds, string startDate, string endDate, string interval)
        {
            long sDate = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long eDate = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Energy> allpowersupply = _context.Energy.ToList();
            List<Energy> matchingAllpowerSupply = allpowersupply.Where(powersupplyid => powersupplyIds.Contains(powersupplyid.PowerSupplyId)).ToList();
            List<Energy> list = matchingAllpowerSupply.Where(powersupplyid => powersupplyid.StartTime >= sDate).ToList().Where(powersupplyid => powersupplyid.StartTime <= eDate).ToList();
            return list;
        }
        public List<Bills> GetBillByFilters(List<string> Ids, string startDate, string endDate)
        {
            long sDate = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long eDate = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> allpowersupply = _context.Bills.ToList();
            List<Bills> matchingAllpowerSupply = allpowersupply.Where(powersupplyid => Ids.Contains(powersupplyid.PowerSupplyId)).ToList();
            List<Bills> list = matchingAllpowerSupply.Where(powersupplyid => powersupplyid.Date >= sDate).ToList().Where(powersupplyid => powersupplyid.Date <= eDate).ToList();
            return list;
        }

    }
}
