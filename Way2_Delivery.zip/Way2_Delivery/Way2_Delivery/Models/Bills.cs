﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Bills
    {
        public string PowerSupplyId { get; set; }
        public string PowerSupplyName { get; set; }
        public decimal Processed { get; set; }
        public decimal Notprocessed { get; set; }
        public decimal Late { get; set; }
        public string Type { get; set; }
        public long Date { get; set; }
    }
}
