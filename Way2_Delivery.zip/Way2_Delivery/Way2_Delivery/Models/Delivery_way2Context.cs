﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Way2_Delivery.Models
{
    public partial class Delivery_way2Context : DbContext
    {
        public Delivery_way2Context()
        {
        }

        public Delivery_way2Context(DbContextOptions<Delivery_way2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Bills> Bills { get; set; }
        public virtual DbSet<Energy> Energy { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=Delivery_way2;Trusted_Connection=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Bills>(entity =>
            {
                entity.HasKey(e => e.PowerSupplyId)
                    .HasName("PK__BILLS__0E834E48CD2CF230");

                entity.ToTable("BILLS");

                entity.Property(e => e.PowerSupplyId).ValueGeneratedNever();

                entity.Property(e => e.Late)
                    .HasColumnName("late")
                    .HasColumnType("numeric(19, 5)");

                entity.Property(e => e.Notprocessed).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.PowerSupplyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Processed)
                    .HasColumnName("processed")
                    .HasColumnType("numeric(19, 5)");

                entity.Property(e => e.Type)
                    .HasColumnName("type")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Energy>(entity =>
            {
                entity.HasKey(e => e.PowerSupplyId)
                    .HasName("PK__ENERGY__0E834E487C3C822A");

                entity.ToTable("ENERGY");

                entity.Property(e => e.PowerSupplyId).ValueGeneratedNever();

                entity.Property(e => e.PowerSupplyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });
        }
    }
}
