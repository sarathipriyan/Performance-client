﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Energy
    {
        public String PowerSupplyId { get; set; }
        public string PowerSupplyName { get; set; }
        public int IdPlant { get; set; }
        public int IdEnergy { get; set; }
        public long StartTime { get; set; }
        public long EndTime { get; set; }
        public double GeneratedCredits { get; set; }
        public double Consumption { get; set; }
        public double Balance { get; set; }
        public double Credits { get; set; }
        public double CumulativeBalance { get; set; }
        public int NumberofUcs { get; set; }
        public long DailyDate { get; set; }
    }
}
