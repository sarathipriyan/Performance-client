﻿using GraphQL;
using GraphQL.Types;

namespace Way2_Delivery.Schemas
{
    public class GeneralSchema : Schema
    {
        public GeneralSchema(IDependencyResolver resolver) : base(resolver)
        {
            Query = resolver.Resolve<GeneralQuery>();
        }
    }
}
