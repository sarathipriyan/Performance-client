﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class BillInputtype : ObjectGraphType<Bills>
    {
        public BillInputtype()
        {
            Field(x => x.PowerSupplyId, type: typeof(IdGraphType)).Description("Id property from the powersupply object.");
            Field(x => x.PowerSupplyName, type: typeof(StringGraphType)).Description("Name property from the Powesupply.");
            Field(x => x.Processed, type: typeof(IdGraphType)).Description("PlantId property from the Plant object.");
            Field(x => x.Notprocessed, type: typeof(IdGraphType)).Description("PlantId property from the Plant object.");
            Field(x => x.Late, type: typeof(IdGraphType)).Description("PlantId property from the Plant object.");
            Field(x => x.Type, type: typeof(StringGraphType)).Description("PlantId property from the Plant object.");
            Field(x => x.Date, type: typeof(IdGraphType)).Description("PlantId property from the Plant object.");
        }
    }
}