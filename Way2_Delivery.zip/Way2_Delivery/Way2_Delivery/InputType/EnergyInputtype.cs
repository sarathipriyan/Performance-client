﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class EnergyInputtype : ObjectGraphType<Energy>
    {
        public EnergyInputtype()
        {
            Field(x => x.PowerSupplyId, type: typeof(IdGraphType)).Description("Id property from the powersupply object.");
            Field(x => x.PowerSupplyName, type: typeof(StringGraphType)).Description("Name property from the Powesupply.");
            Field(x => x.IdPlant, type: typeof(IdGraphType)).Description("PlantId property from the Plant object.");
            Field(x => x.IdEnergy, type: typeof(IdGraphType)).Description("EnergyID property from the Energy object.");
           // Field(x => x.StartTime, type: typeof(StringGraphType)).Description("Start Time.");
            //Field(x => x.EndTime, type: typeof(StringGraphType)).Description("End Time.");
            Field(x => x.GeneratedCredits, type: typeof(DecimalGraphType)).Description("Generated Credits.");
            Field(x => x.Consumption, type: typeof(DecimalGraphType)).Description("Consumption.");
            Field(x => x.Balance, type: typeof(DecimalGraphType)).Description("Balance");
            Field(x => x.Credits, type: typeof(DecimalGraphType)).Description("Credits");
            Field(x => x.CumulativeBalance, type: typeof(DecimalGraphType)).Description("CumulativeBalance");
            //Field(x => x.DailyDate, type: typeof(StringGraphType)).Description("Datedaily");
        }
    }
}