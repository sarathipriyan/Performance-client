﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class EnergyGeneratedData1 : ObjectGraphType<EnergyGeneratedData>
    {
        public EnergyGeneratedData1()
        {
            Field(x => x.Value, type: typeof(DecimalGraphType)).Description("Value Credits data.");
            Field(x => x.timestamp, type: typeof(StringGraphType)).Description("Value Credits data.");
        }
    }
}
