﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.Repo
{
    public class GeneralRepository : IGeneralRepository
    {
        public readonly WAY2_DBContext _context;
        public GeneralRepository(WAY2_DBContext context)
        {
            _context = context;
        }
        public EnergyDataResponse GetEnergyDataByFilters(List<string> powerSupplyIds, string startDate, string endDate, Interval interval)
        {
            //calculate total installed capacity of all plants
            long allPlantsCapacity = 0;
            String plantName = String.Empty;

            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Energy> energyData = getEnergyDataByPowerSupplyIds(powerSupplyIds);
            if(energyData.Count > 0 )
            {
                energyData = energyData.Where(energy => energy.DateTime >= startTime).ToList();
                energyData = energyData.Where(energy => energy.DateTime <= endTime).ToList();

            }
            if(interval.Equals(Interval.Daily))
            {
                Dictionary<string, Energy> aggEnergyPerDay = new Dictionary<string, Energy>();
                for (int i=0; i < energyData.Count; i ++ )
                {
                    DateTime energyTime = Epoch2UTCNow(energyData[i].DateTime);
                    String Date = energyTime.ToString("yyyy-MM-dd");

                    aggregateEnergyData(aggEnergyPerDay, energyData[i],Date);
                    
                }
                energyData = aggEnergyPerDay.Select(x => x.Value).ToList();

                for(int i=0; i<powerSupplyIds.Count; i++)
                {
                    List<Plantdata> plants = _context.Plantdata.ToList().Where(plant => plant.Id == int.Parse(powerSupplyIds[i])).ToList();
                   // List<Plantdata> plants = _context.Plantdata.ToList().Where(plant => plant.Id ==powerSupplyIds[i]).ToList();
                    if (plants.Count == 1)
                    {
                        Plantdata plant = plants[0];
                        allPlantsCapacity += plant.InstalledCapacity;
                        //get the first plant name
                        if (i == 0)
                        {
                            plantName = plant.Name;
                        }

                    }
                    else if(plants.Count == 0) 
                    {
                        //log a error sayingno plant exist with this plantId
                    } else
                    {
                        //log a error about more than one plant forsamme id
                    }

                }

            }
        

            EnergyDataResponse energyResp = convertEnergyDataToResponse(energyData, powerSupplyIds, allPlantsCapacity, plantName);
            return energyResp;
        }

        private void aggregateEnergyData(Dictionary<string, Energy> aggEnergy, Energy currEnergy, String date)
        {
            //get the epoch time for the date with midnight time ie YYYY-MM_DDT00:00:00
            DateTime dt = DateTime.ParseExact(date, "yyyy-MM-dd", null);
            long epoch = DateTimeToEpoch(dt);

            if (aggEnergy.ContainsKey(date))
            {
                Energy newData = aggregateData(currEnergy, aggEnergy.GetValueOrDefault(date));
                newData.DateTime = epoch;
                aggEnergy[date] = newData;
            } else
            {
                currEnergy.DateTime = epoch;
                aggEnergy.Add(date, currEnergy);
            }
            
        }

        private Energy aggregateData(Energy currEnergy, Energy energy)
        {
            currEnergy.Value += energy.Value;
            return currEnergy;
        }

        private DateTime Epoch2UTCNow(long epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(epoch);
        }

        private long DateTimeToEpoch(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan diff = date.ToUniversalTime() - origin;
            return Convert.ToInt64(diff.TotalSeconds);
        }
        private List<Energy> getEnergyDataByPowerSupplyIds(List<String> ids)
        {
            List<Energy> energyData = new List<Energy>();
            List<Energy> Energy = _context.Energy.ToList();
            energyData = Energy.Where(energy => ids.Contains(energy.IdPlant.ToString())).ToList();
            return energyData;
        }

        public EnergyDataResponse convertEnergyDataToResponse(List<Energy> energyDataList, List<string> powerSupplyIds, long totalCapacity, String plantName)
        {
        
            
            EnergyDataResponse respData = new EnergyDataResponse();
            respData.data = new List<EnergyGeneratedData>();
            respData.totalInstalledCapacity = totalCapacity;

            foreach (var energyData in energyDataList)
            {
                EnergyGeneratedData data = new EnergyGeneratedData();
                data.Value = energyData.Value;
                data.timestamp = Epoch2UTCNow(energyData.DateTime);
                respData.data.Add(data);
 
            }
            if (powerSupplyIds.Count == 1)
            {
                Plantdata plant = _context.Plantdata.ToList().Where(p => p.Id == int.Parse(powerSupplyIds[0])).ToList()[0];


                respData.billExpectedDate = plant.PowerBillExpectedDate.ToString();
            }

            return respData;
        }

        public String getPowerSupplyNameFromId(int id)
        {
          // List<Plantdata> plantidlist = _context.Plantdata.ToList().Where(energy => id.Contains(energy.Id.ToString())).ToList();
            List<Plantdata> plantidlist = _context.Plantdata.ToList().Where(energy => energy.Id == id).ToList();
            
            String PlantName = "";
            if (plantidlist.Count == 1)
            {
                PlantName = plantidlist[0].Name;
            }
            return PlantName;
        }
        public String getPowersupplyNameFromID(int id)
        {
            String powerSupplyName = "";
            List<Plantdata> pds = _context.Plantdata.ToList().Where(distributor => distributor.Id == id).ToList();
            if (pds.Count == 1)
            {
                powerSupplyName = pds[0].Name;
            }
            return powerSupplyName;
        }
        public List<BillResponse> GetBillStatusByFilters(List<string> powerSupplyIds, string startDate, string endDate, Interval interval)
        {
            List<BillResponse> billResp = new List<BillResponse>();
            List <BillResponse> billData = new List<BillResponse>();
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> BillData = getBillDataByPowerSupplyIds(powerSupplyIds);
            if (BillData.Count > 0)
            {
                BillData = BillData.Where(bill => bill.ReferenecDate >= startTime).ToList();
                BillData = BillData.Where(bill => bill.ReferenecDate <= endTime).ToList();

            }

            //split the billdata to generated and  consumer
            List<Bills> generatedBillData = BillData.Where(bill => bill.Type == (int)BillType.Generated).ToList();
            List<Bills> consumerBillData = BillData.Where(bill => bill.Type == (int)BillType.Consumption).ToList();

            //if there is a monthly interval type, aggregate the bills based on the monthh
            //else pl aggregate between start and end date.
            if (interval.Equals(Interval.Monthly))
            {
                Dictionary<String,BillStatusAggregate> generatedAggregateBills = processBillsPerMonth(generatedBillData);
                Dictionary<String, BillStatusAggregate> consumerAggregateBills = processBillsPerMonth(consumerBillData);

                billResp.AddRange(getMonthlyBillStatus(generatedAggregateBills, BillType.Generated));
                billResp.AddRange(getMonthlyBillStatus(consumerAggregateBills, BillType.Consumption));
                // return genAggList;

                //billResp.Add(convertBillDataToResponse(generatedAggregateBills, BillType.Generated));
                //billResp.Add(convertBillDataToResponse(consumerAggregateBills, BillType.Consumption));

            }
            return billResp;
        }

        
        

        private List<BillResponse> getMonthlyBillStatus(Dictionary<String, BillStatusAggregate> generatedAggregatedBill, BillType type)
        {
            List<BillResponse> billStatusList = new List<BillResponse>();


            foreach (KeyValuePair<String, BillStatusAggregate> item in generatedAggregatedBill)
            {
                int totalCnt = item.Value.processedBillCnt + item.Value.nonProcessedBillCnt + item.Value.lateBillsCnt;
                BillResponse billStatus = new BillResponse();
                billStatus.processed = item.Value.processedBillCnt * 100 / totalCnt;
                billStatus.notProcessed = item.Value.nonProcessedBillCnt * 100 / totalCnt;
                billStatus.late = item.Value.lateBillsCnt * 100 / totalCnt;
                billStatus.type = type;
                billStatus.timestamp = DateTime.ParseExact(item.Key,"yyyy-MM", null);
                    
                billStatusList.Add(billStatus);

            }
            return billStatusList;
            
        }

    private Dictionary<string, BillStatusAggregate> processBillsPerMonth(List<Bills> BillData)
    {
        Dictionary<string, BillStatusAggregate> aggBillStatusPerMonth = new Dictionary<string, BillStatusAggregate>();
            for (int i = 0; i < BillData.Count; i++)
            {
                DateTime BillTime = Epoch2UTCNow(BillData[i].ReferenecDate);
                String Month = BillTime.ToString("yyyy-MM");

                 aggregateBillStatusPerMonth(aggBillStatusPerMonth, BillData[i], Month);
                
            }
           
            //BillData = aggBillStatusPerMonth.Select(x => x.Value).ToList();
            return aggBillStatusPerMonth;

        }

    private void aggregateBillStatusPerMonth(Dictionary<string, BillStatusAggregate> aggBill, Bills currBill, String Month)
        {
            //get the epoch time for the date with midnight time ie YYYY-MM_DDT00:00:00
            DateTime dt = DateTime.ParseExact(Month, "yyyy-MM", null);
            long epoch = DateTimeToEpoch(dt);

            BillStatusAggregate newAgg = new BillStatusAggregate();
            newAgg.processedBillCnt = newAgg.nonProcessedBillCnt = newAgg.lateBillsCnt = 0;

            
            if (aggBill.ContainsKey(Month))
            {
                newAgg = aggBill.GetValueOrDefault(Month);
                newAgg = aggregateBillStatusData(currBill, aggBill.GetValueOrDefault(Month));
                //agg.ReferenecDate = epoch;
               // aggBill[Month] = newData;
                //aggBill.Add(Month, )
            }
            newAgg = aggregateBillStatusData(currBill, newAgg);
            aggBill[Month] = newAgg;

        }

        private BillStatusAggregate aggregateBillStatusData(Bills currBill, BillStatusAggregate aggBill)
        {

            ///if (currBill.BillStatus == 1)
            // {
            //   aggBill.processedBillCnt += 1;
            // }

            switch (currBill.BillStatus)
            {

                case 1:
                    aggBill.processedBillCnt += 1;
                    break;

                case 2:
                    aggBill.nonProcessedBillCnt += 2;
                    break;

                case 3:
                    aggBill.lateBillsCnt += 3;
                    break;
            }

            return aggBill;
        }

        public BillResponse convertBillDataToResponse(List<Bills> billdata, BillType type)
        {
            List<BillResponse> respData = new List<BillResponse>();
            BillResponse tmpData = new BillResponse();

            List<string> powerSupplyIds = billdata.Select(x => x.IdConsumerNavigation.IdPlant.ToString()).ToList();
            int processedBillCnt = 0;
            int nonProcessedBillCnt = 0;
            int lateProcessedBillCnt = 0;

            for (int i = 0; i < powerSupplyIds.Count; i++)
            {
        
                Plantdata plant = _context.Plantdata.ToList().Where(x => x.Id == int.Parse(powerSupplyIds[i])).ToList()[0];

                processedBillCnt += billdata.ToList().Where(data => data.IdConsumerNavigation.IdPlant == int.Parse(powerSupplyIds[i])).ToList()
                .Count(x => x.BillStatus == 1);
                nonProcessedBillCnt += billdata.ToList().Where(data => data.IdConsumerNavigation.IdPlant == int.Parse(powerSupplyIds[i])).ToList()
                .Count(x => x.BillStatus == 2);
                lateProcessedBillCnt += billdata.Where(data => int.Parse(powerSupplyIds[i]) == data.IdConsumerNavigation.IdPlant).ToList()
                .Count(x => x.BillStatus == 3);

            }

            tmpData.processed = (processedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
            tmpData.notProcessed = (nonProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
            tmpData.late = (lateProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
            tmpData.type = type;
            tmpData.timestamp = new DateTime();
           

            if (powerSupplyIds.Count == 1)
            {
                tmpData.powerSupplyId = int.Parse(powerSupplyIds[0]);
                tmpData.powerSupplyName = getPowersupplyNameFromID(tmpData.powerSupplyId);
            }
            
            return tmpData;
        }

       

        private List<Bills> getBillDataByPowerSupplyIds(List<String> ids)
        {
            List<Bills> BillData = new List<Bills>();
            List<Consumerdata> ConsumerData = new List<Consumerdata>();
           
               ConsumerData = _context.Consumerdata.ToList().Where(consumer => ids.Contains(consumer.IdPlant.ToString())).ToList();
               List<int> Consumerids= ConsumerData.ToList().Select(x => x.Id).ToList();
               BillData = _context.Bills.ToList();
               BillData = BillData.Where(bill => Consumerids.Contains(bill.IdConsumer)).ToList();

            
            return BillData;
        }
        public List<BillDataResponse> GetBillDataByFilters(List<string> powerSupplyIds, string startDate, string endDate)
        {
            List<BillResponse> billData = new List<BillResponse>();
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> BillData = getBillDataByIds(powerSupplyIds);
            if (BillData.Count > 0)
            {
                BillData = BillData.Where(bill => bill.ReferenecDate >= startTime).ToList();
                BillData = BillData.Where(bill => bill.ReferenecDate <= endTime).ToList();

            }

            
            List<BillDataResponse> billResp = convertSumofBillDataToResponse(powerSupplyIds, BillData);
            
            return billResp;
        }
        private List<Bills> getBillDataByIds(List<String> ids)
        {
            List<Bills> BillData = new List<Bills>();
            List<Consumerdata> ConsumerData = new List<Consumerdata>();

            ConsumerData = _context.Consumerdata.ToList().Where(consumer => ids.Contains(consumer.IdPlant.ToString())).ToList();
            List<int> Consumerids = ConsumerData.ToList().Select(x => x.Id).ToList();
            BillData = _context.Bills.ToList();
            BillData = BillData.Where(bill => Consumerids.Contains(bill.IdConsumer)).ToList();


            return BillData;
        }
        public List<BillDataResponse> convertSumofBillDataToResponse(List<string> powerSupplyIds, List<Bills> billdata)
        {
            List<BillDataResponse> respData = new List<BillDataResponse>();
            BillDataResponse tmpData = new BillDataResponse();
            for (int i = 0; i < billdata.Count; i++)
             {

                tmpData.CumulativeGeneration += billdata[i].CumulativeGeneration;
            }
            
            if (powerSupplyIds.Count == 1)
            {
                int plantId = int.Parse(powerSupplyIds[0]);
                List<Plantdata> plantList = _context.Plantdata.ToList().Where(plant => plant.Id == plantId).ToList();
                if (plantList.Count == 1)
                {
                    tmpData.powerSupplyId = plantId;
                    tmpData.powerSupplyName = plantList[0].Name;
                }

            }
            respData.Add(tmpData);
            return respData;
        }


    }
}
