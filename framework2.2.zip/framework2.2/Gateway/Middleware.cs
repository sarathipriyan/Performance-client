﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gateway
{
    public class GetConnStringFromdomainMiddleWare
    {
        private readonly RequestDelegate _next;

        public GetConnStringFromdomainMiddleWare(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext context)
        {
            //get the domain name from http context
            //lookup core DB to find the corresponding connection string for the domain
            //pass this connection string as header info (or append it as queryString)
            Dictionary<string, string> connectionStrList =Repo.GetConnectionString();
            string urlOrigin = context.Request.Headers["Origin"];
            if (connectionStrList != null && connectionStrList.Count > 0)
            {
                if (!string.IsNullOrEmpty(urlOrigin) && connectionStrList.ContainsKey(urlOrigin))
                {
                    context.Request.Headers.Add("domain", urlOrigin);
                    context.Request.Headers.Add("connectionString", connectionStrList[urlOrigin]);
                }
            }

            // Call the next delegate/middleware in the pipeline
            return this._next(context);
        }
    }
}
