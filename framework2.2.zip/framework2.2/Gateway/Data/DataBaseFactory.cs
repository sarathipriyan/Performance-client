﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gateway.Data
{
    public class DataBaseFactory
    {
        public static string connStr { get; set; }

        public static DataBaseContext Create()
        {
            if (!string.IsNullOrEmpty(connStr))
            {
                var optionsBuilder = new DbContextOptionsBuilder<DataBaseContext>();
                optionsBuilder.UseSqlServer(connStr);
                return new DataBaseContext(optionsBuilder.Options);
            }
            else
            {
                throw new ArgumentNullException("ConnectionId");

            }
        }
    }
}
