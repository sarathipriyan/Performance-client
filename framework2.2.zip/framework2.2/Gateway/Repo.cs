﻿using Gateway.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace Gateway
{
    public class Repo
    {
        private string _urlConexao { get; set; }

        public Repo(string urlConexao)
        {
            this._urlConexao = urlConexao;
        }

        public static Dictionary<string, string> GetConnectionString()
        {
            try
            {
                using (var db = DataBaseFactory.Create())
                {
                    db.Database.OpenConnection();

                    using (var command = db.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = "Select * from sarathi";
                        command.CommandTimeout = 3600;
                        command.CommandType = CommandType.Text;

                        DbDataReader resultado = command.ExecuteReader();

                        var resultados = new Dictionary<string, string>();

                        if (resultado.HasRows)
                        {
                            while (resultado.Read())
                            {
                                string url = (string)resultado["Url"];
                                string connectionString = (string)resultado["ConnectionString"];
                                resultados.Add(url, connectionString);
                            }
                        }

                        resultado.Close();

                        return resultados;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}

