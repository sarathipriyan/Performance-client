﻿using framework2._2.Models;
using GraphQL.Types;
using Mtest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace framework2._2.planttype
{
    public class PlanttypeClass : ObjectGraphType<Sarathi>
    {
        public PlanttypeClass()
        {
           Field(a => a.Id);
           Field(a => a.Name);
            //Field(a => a.PowerBillExpectedDate);
            //  Field(a => a.TypeofDistributedEnergy);
            // Field(a => a.Source);
            // Field(a => a.InstalledCapacity);



          //  Field<StringGraphType>(
          //  "id",
           // resolve: context => context.Source.Id.ToString());


          //  Field<StringGraphType>(
          // "Name",
         //  resolve: context => context.Source.Name.ToString());

           // Field<StringGraphType>(
           // "TimeStampCome",
           /// resolve: context => context.Source.startdate.ToString());
//
          //  Field<StringGraphType>(
           //     "TimeStampGone",
             //   resolve: context => context.Source.enddate.ToString());
        }
    }
}
