﻿using GraphQL.Types;
using framework2._2.planttype;
using framework2._2.Models;
using framework2._2;
using System.Collections.Generic;
using System;

namespace Mtest
{
    public class PlantQuery : ObjectGraphType
    {
        public PlantQuery(IPlantRepository employeeRepository)
        {
            Field<ListGraphType<PlanttypeClass>>(
                "Plants",
                resolve: context => employeeRepository.GetPlants()

                );
         

        }
    }
}

