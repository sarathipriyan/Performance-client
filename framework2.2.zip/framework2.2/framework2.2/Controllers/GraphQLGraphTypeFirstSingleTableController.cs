﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using framework2._2.Models;
using GraphQL;
using GraphQL.Client;
using GraphQL.Common.Request;
using GraphQL.Types;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mtest;

namespace framework2._2.Controllers
{
    public class GraphQLGraphTypeFirstSingleTableController : Controller
    {
        [Route("sarathi")]
        [Authorize]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public class TESTController : Controller
        {
            [HttpGet]
            public async Task<List<Sarathi>> Get()
            {
                using (GraphQLClient graphQLClient = new GraphQLClient("http://localhost:64034/graphql"))
                {
                    var query = new GraphQLRequest
                    {
                        Query = @"   
                        { Plants   
                            { name id }   
                        }",
                    };
                    var response = await graphQLClient.PostAsync(query);
                    return response.GetDataFieldAs<List<Sarathi>>(" Plants");
                }
            }

            [HttpPost]
            public async Task<Sarathi> Post([FromBody] PlantQuery query)
            {

                using (GraphQLClient graphQLClient = new GraphQLClient("http://localhost:64034/graphql"))
                {
                    //var schema = new Schema { Query = new Appquery(AppSzz) };
                    var query1 = new GraphQLRequest
                    {
                        Query = @"   
                        { Plants   
                            { name id }   
                        }",
                        Variables = new { owner = query }
                    };
                    var response = await graphQLClient.PostAsync(query1);
                    return response.GetDataFieldAs<Sarathi>("Plants");
                }
            }
        }
    }
}
