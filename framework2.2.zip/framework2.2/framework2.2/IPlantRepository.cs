﻿using framework2._2.Models;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mtest
{
    public interface IPlantRepository
    {
        Task<List<Sarathi>> GetPlants();
        Sarathi CreatePlants(Sarathi plant);
        Sarathi GetById(long owner);
        List<Sarathi> GetBooksByIdList(List<String> bookIds);
    }
}
