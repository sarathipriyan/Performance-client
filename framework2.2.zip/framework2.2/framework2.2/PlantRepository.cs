﻿using framework2._2.Models;
using GraphQL.Types;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mtest
{
    public class PlantRepository : IPlantRepository
        {
            private readonly sarathidemoContext _context;
            public PlantRepository(sarathidemoContext context)
            {
                _context = context;
            }

            public Task<List<Sarathi>> GetPlants()
            {
                return _context.Sarathi.ToListAsync();
            }
        public Sarathi CreatePlants(Sarathi plant)
        {
            //sarathi.Id = Guid.NewGuid().;
            _context.Add(plant);
            _context.SaveChanges();
            return plant;
        }
        public Sarathi GetById(long owner) => _context.Sarathi.SingleOrDefault(o => o.Id.Equals(owner));


        public  List<Sarathi> GetBooksByIdList(List<String> bookIds)
        {
            List<Sarathi> allBooks = _context.Sarathi.ToList();
            List<Sarathi> matchingBooks = allBooks.Where(Sarathi => bookIds.Contains(Sarathi.Id)).ToList();
            return matchingBooks;
        }

    }
}


