﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace framework2._2.Models
{
    public partial class Sarathi
    {
        public string Id { get; set; }
        public string Name { get; set; }

        //public DateTime startdate { get; set; }
        //public DateTime enddate { get; set; }
    }
}
