﻿using framework2._2.Models;
using GraphQL.Types;
using Mtest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace framework2._2
{
    public class InputType : ObjectGraphType<Sarathi>
    {
        public InputType()
        {
            Field(x => x.Id, type: typeof(IdGraphType)).Description("Id property from the owner object.");
            Field(x => x.Name, type: typeof(IdGraphType)).Description("Name property from the owner object.");
        }
    }
}
