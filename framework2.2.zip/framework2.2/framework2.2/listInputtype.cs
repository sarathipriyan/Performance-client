﻿using framework2._2.Models;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace framework2._2
{
    public class listInputtype : ObjectGraphType<Sarathi>
    {
        public listInputtype()
        {
            Field(x => x.Id, type: typeof(ListGraphType)).Description("Id property from the owner object.");
            //Field(x => x.Name, type: typeof(IdGraphType)).Description("Name property from the owner object.");
        }
    }
}
