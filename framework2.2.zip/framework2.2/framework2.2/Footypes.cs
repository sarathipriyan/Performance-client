﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace framework2._2
{
    public class Footypes
    {
    }
}
