﻿using GraphQL;
using GraphQL.Types;
using Mtest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace framework2._2.plantschema
{
    public class plantSchemaClass : Schema
    {
        public plantSchemaClass(IDependencyResolver resolver) : base(resolver)
        {
            Query = resolver.Resolve<PlantQuery>();
            Mutation = resolver.Resolve<AppMutation>();
        }
    }
}

