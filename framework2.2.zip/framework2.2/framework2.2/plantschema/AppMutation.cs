﻿using framework2._2.Models;
using GraphQL;
using GraphQL.Types;
using Mtest;
using System;
using System.Collections.Generic;

namespace framework2._2.plantschema
{
    public class AppMutation : ObjectGraphType
    {
         public AppMutation(IPlantRepository repository)
            {
                Field<InputType>(
                    "createPlant",
                  arguments: new QueryArguments(new QueryArgument<NonNullGraphType<PlantInputType>> { Name = "plant" }),
                    resolve: context =>
                    {
                        var plant = context.GetArgument<Sarathi>("plant");
                        return repository.CreatePlants(plant);
                    }
                );

            Field<InputType>(
                "GetById",
                arguments: new QueryArguments(new QueryArgument<NonNullGraphType<IdGraphType>>{ Name = "owner" }),
                resolve: context =>
                {
                    var owner = context.GetArgument<int>("owner");
                    return repository.GetById(owner);

                }
            );

            Field<ListGraphType<InputType>>("book",
          arguments: new QueryArguments(
  new QueryArgument<ListGraphType<StringGraphType>> { Name = "id" }
), resolve: context =>
{
   List<String> idList = context.GetArgument<List<String>>("id");
   return repository.GetBooksByIdList(idList);
});
        }

    }
}