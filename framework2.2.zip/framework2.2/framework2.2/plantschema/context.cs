﻿namespace framework2._2.plantschema
{
    internal class context
    {
    }
}