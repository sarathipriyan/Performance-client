﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class BillDataInputtype : ObjectGraphType<BillDataResponse>
    {
        public BillDataInputtype()
        {
            Field(x => x.powerSupplyId, type: typeof(StringGraphType)).Description("Id of the Plant for this bill");
            Field(x => x.powerSupplyName, type: typeof(StringGraphType)).Description("Name of the Plant for this bill");
            Field(x => x.CumulativeGeneration, type: typeof(DecimalGraphType)).Description("CumulativeGeneration data");
        }
    }
}
