﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public enum Interval
    {
        Daily = 1,
        Weekly = 2
    }
    public partial class Energy
    {
        public int Id { get; set; }
        public int IdPlant { get; set; }
        public DateTime InsertedAt { get; set; }
        public long DateTime { get; set; }
        public decimal Value { get; set; }
        public int ToU { get; set; }
        public int Quality { get; set; }

        public virtual Plantdata IdPlantNavigation { get; set; }
    }
}
