﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Plantdata
    {
        public Plantdata()
        {
            Consumerdata = new HashSet<Consumerdata>();
            Energy = new HashSet<Energy>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Source { get; set; }
        public string TypeofDistributedEnergy { get; set; }
        public int IdPowerDistributor { get; set; }
        public long InstalledCapacity { get; set; }
        public DateTime PowerBillExpectedDate { get; set; }
        public string MeasuringPoint { get; set; }

        public virtual Powerdistributor IdPowerDistributorNavigation { get; set; }
        public virtual ICollection<Consumerdata> Consumerdata { get; set; }
        public virtual ICollection<Energy> Energy { get; set; }
    }
}
