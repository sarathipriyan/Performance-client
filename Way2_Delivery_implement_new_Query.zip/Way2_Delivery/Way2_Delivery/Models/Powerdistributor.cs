﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Powerdistributor
    {
        public int Id { get; set; }
        public string PowerDistributorName { get; set; }

        public virtual Plantdata Plantdata { get; set; }
    }
}
