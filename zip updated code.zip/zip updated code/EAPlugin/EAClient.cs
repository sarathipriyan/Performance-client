﻿using CogCDS_EAPlugin;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace CogCDS_EAPlugin
{
    public class EAClient
    {
        private string ip = string.Empty;
        public void EA_client_init(string url)
        {
            ip = url;
        }
        public HttpWebResponse GetRoot(string conString, string xml, string reqType, bool headersExist)
        {
            string fullConString = string.Format("{0}/{1}", ip, conString);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullConString);
            //Set the parameters for the web request
            request.Method = reqType;
            request.Accept = "application/xml";
            request.KeepAlive = true;
            request.AllowAutoRedirect = true;
            HttpWebResponse httpResponse = (HttpWebResponse)request.GetResponse();
            return httpResponse;

        }

        public HttpWebResponse GetNestedResources(string conString, string xml, string reqType, bool headersExist, string nestedResourcesLink)
        {
            HttpWebRequest request = null;
            if (string.IsNullOrEmpty(nestedResourcesLink))
            {
                string fullConString = string.Format("{0}/{1}", ip, conString);
                request = (HttpWebRequest)WebRequest.Create(fullConString);
            }
            else
            {
                request = (HttpWebRequest)WebRequest.Create(nestedResourcesLink);
            }

            //Set the parameters for the web request
            request.Method = reqType;
            request.Accept = "application/xml";
            request.KeepAlive = true;
            request.AllowAutoRedirect = true;
            HttpWebResponse httpResponse = (HttpWebResponse)request.GetResponse();
            return httpResponse;
        }

        public HttpWebResponse CreateResources(string conString, string xml, string reqType, bool headersExist)
        {
            string fullConString = string.Format("{0}/{1}", ip, conString);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullConString);
            byte[] requestBytes = System.Text.Encoding.UTF8.GetBytes(xml);
            request.ContentType = "application/xml";
            request.ContentLength = requestBytes.Length;
            request.Method = "POST";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(requestBytes, 0, requestBytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();
                
            }
            return response;
        }

        public HttpWebResponse DeletePackageById(string conString, string reqType, bool headersExist)
        {
            string fullConString = string.Format("{0}/{1}", ip, conString);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullConString);
            request.ContentType = "application/xml";
            request.Method = reqType;
            request.KeepAlive = true;
            request.AllowAutoRedirect = true;
            HttpWebResponse httpResponse = (HttpWebResponse)request.GetResponse();
            return httpResponse;
        }

        public HttpWebResponse  UpdateEA(string conString, string xml, string reqType, bool headersExist)
        {
            string fullConString = string.Format("{0}/{1}", ip, conString);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullConString);
            byte[] requestBytes = System.Text.Encoding.UTF8.GetBytes(xml);
            request.ContentType = "application/xml";
            request.ContentLength = requestBytes.Length;
            request.Method = "POST";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(requestBytes, 0, requestBytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();

            }
            return response;
        }
    }
}

