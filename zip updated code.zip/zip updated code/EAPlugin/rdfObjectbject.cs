﻿namespace CogCDS_EAPlugin
{
    public class rdfObject
    {
        public string title { get; set; }
        public string type { get; set; }
        public string identifier { get; set; }
        public string nestedresources { get; set; }
        public string parentUid { get; set; }
        public string description { get; set; }

    }
}