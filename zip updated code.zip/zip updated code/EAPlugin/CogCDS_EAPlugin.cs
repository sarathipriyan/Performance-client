﻿using CogPluginInterface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using VDS.RDF;

namespace CogCDS_EAPlugin
{
    public enum RuleAction
    {
        Ignore = 0,
        Create = 1,
        Remove = 2
    }
    public class CogCDS_EAPlugin : ICogPlugin
    {
        private Logger loggerCallback;
        private string EAProjectKey;
        private Notify notifyCallback;
        private EAClient eAClient;
        private string cockpitProjectName;
        private string pluginNumber;                            //Which plugin the EA Plugin is being run as e.g. plugin1 or plugin2
        private DecryptPassword decryptCallback;
        private string cockpitProjectKey;
        private Dictionary<string, Dictionary<string, string>> dataMappingLookup;
        private Dictionary<string, string> cockpitTypeMapping;  //Mapping of cockpit data types to TFS issue types (e.g. requirement -> user story, defect -> bug, etc.), loaded in at run time
        //private string idFieldName;                             //Name of the EA id field in cockpit, e.g. sUDA_Tfs_ID
        private string eArootName;                            //Name of the EA key field in cockpit, e.g. sUDA_Tfs_Key
        private string urlPrefix = string.Empty;

       // private string cockpitUIDName;
        //private Dictionary<string, string> EANameIdMapping;   //Mapping of EA field names to their field ids
        private Dictionary<string, Dictionary<string, string>> cockpitTypeFieldMapping;
        private Dictionary<string, string> eATypeMapping;
        private Dictionary<string, Dictionary<string, Dictionary<string, object>>> cockpitEADataMapping;
        private Dictionary<string, rdfObject> association;
        //private Dictionary<string, string> sReqTypeMapping;
        private List<string> listofItemsEa;
        private readonly string logPrefix = "EA plugin,";
        private EAClient eaClient = new EAClient();
        public bool Initialize(Logger loggerCallback, Notify notifyCallback, DecryptPassword decryptCallback)
        {
            this.cockpitProjectName = string.Empty;
            this.cockpitProjectKey = string.Empty;
            this.notifyCallback = notifyCallback;
            this.eATypeMapping = new Dictionary<string, string>();
            this.cockpitTypeFieldMapping = new Dictionary<string, Dictionary<string, string>>();
            this.cockpitTypeMapping = new Dictionary<string, string>();
            this.listofItemsEa = new List<string>(new string[] {"Cockpit ItemId"});
            this.loggerCallback = loggerCallback;
            this.association = new Dictionary<string, rdfObject>();
            return true;
        }
        public bool Login(string credentialInfo)
        {
            this.loggerCallback("EA , attempting login");
            this.cockpitEADataMapping = new Dictionary<string, Dictionary<string, Dictionary<string, object>>>();
            //Load the credential information and create the EA + cockpit clients
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(credentialInfo);
            this.pluginNumber = xDoc.FirstChild.Name;
            if (xDoc.SelectSingleNode("//EA/rootName") == null) return false;
            this.eArootName = xDoc.SelectSingleNode("//EA/rootName").InnerText;

            if (xDoc.SelectSingleNode("//EA/urlPrefix") == null) return false;
            this.urlPrefix = xDoc.SelectSingleNode("//EA/urlPrefix").InnerText;

            if (xDoc.SelectSingleNode("//EA/project") == null) return false;
            this.EAProjectKey = xDoc.SelectSingleNode("//EA/project").InnerText;


            //Build the EA and cockpit type field mappings
            XmlElement xIssueFieldMapping = xDoc.SelectSingleNode("//mapping[@name='cockpitEAMapping']") as XmlElement;
            if (xIssueFieldMapping == null) return false;
            foreach (XmlElement xItem in xIssueFieldMapping.SelectNodes("./item"))
            {
                string sCockpitType = xItem.GetAttribute("source");
                Dictionary<string, Dictionary<string, object>> targetMap = new Dictionary<string, Dictionary<string, object>>();
                //if new source, add to dictionary
                if (!this.cockpitEADataMapping.ContainsKey(sCockpitType))
                {
                    cockpitEADataMapping.Add(sCockpitType, targetMap);
                }
                else
                {
                    targetMap = cockpitEADataMapping[sCockpitType];

                }
                Dictionary<string, object> dataMapping = new Dictionary<string, object>();
                string sEAType = xItem.GetAttribute("target");
                if (!targetMap.ContainsKey(sEAType))
                {
                    targetMap.Add(sEAType, dataMapping);
                }
                else
                {
                    dataMapping = targetMap[sEAType];
                }
                foreach (XmlElement xMap in xItem.SelectNodes("./map"))
                {
                    string sCockpitAttribute = xMap.GetAttribute("source");
                    string sEAField = xMap.GetAttribute("target");
                    dataMapping.Add(sCockpitAttribute, sEAField);
                }
                this.eATypeMapping.Add(sCockpitType, sEAType);
            }
            this.eaClient.EA_client_init(urlPrefix);
            if (!(VerifyEAPacakge(EAProjectKey, eArootName)))
            {
                this.loggerCallback("EA,login failed");
                return false;
            }
            if (!(VerifyCockpitFields()))
            {
                this.loggerCallback("Jira plugin, failed to verify cockpit fields");
                return false;
            }
            this.loggerCallback("EA, login succeeded");
            return true;
        }

        /// <summary>
        /// Verify that the cockpit data attributes in the cockpitFieldMapping actually exist
        /// </summary>
        /// <returns>True if the cockpit data attributes exist, false otherwise</returns>
        public bool VerifyCockpitFields()
        {
            //TODO: Move to cockpit ui and ASE portion, not possible to do in utility?
            return true;
        }

        #region LoginHelperMethods
        /// <summary>
        /// Verify that the Root  exist in the eA project
        /// </summary>
        /// <returns>True if the Root exist, false otherwise</returns>
        private bool VerifyEAPacakge(string EAProjectKey,string rootName)
        {
            ProcessStatusCode result = ProcessStatusCode.Successful;
            string parentID = null;
            string objectType = string.Empty;
            try
            {
                CogUtility.SetStatusCode(ref result, this.GetParentId(EAProjectKey, objectType, rootName, out parentID, out string GetResponse));
                if (result == ProcessStatusCode.HadUnrecoverableErrors)
                {
                    return false;
                }
                //Root name does not exist in EA
                if (string.IsNullOrEmpty(parentID))
                {
                    loggerCallback(string.Format("EA plugin, Root : {0} does not exist in the specified eA project", rootName));
                    return false;
                }
            }
            catch (Exception ex)
            {
                loggerCallback(string.Format("EA plugin, Error {0} ", ex.Message));
                throw ex;
            }
            return true;
        }

        private RuleAction ParseRule(XmlNode xmlNode)
        {
            try
            {
                string action = xmlNode.Attributes["action"].Value.ToLower();

                switch (action)
                {
                    case "create":
                        return RuleAction.Create;
                    case "remove":
                        return RuleAction.Remove;
                    case "ignore":
                    default:
                        return RuleAction.Ignore;
                }
            }
            catch (Exception)
            {
                string xmlNodeText = "because the rule element was not found";
                if (xmlNode != null)
                {
                    xmlNodeText = xmlNode.OuterXml;
                }
                this.loggerCallback(string.Format("EA Plugin, unable to parse rule {0}", xmlNodeText));
                return RuleAction.Ignore;
            }
        }
        #endregion
        public void Logout()
        {
            //no Need 

        }
        public ProcessStatusCode ProcessData(bool isTarget, string directive, ref string valueData)
        {
            ProcessStatusCode ret = ProcessStatusCode.Successful;
            loggerCallback(string.Format("EA plugin, ProcessData run with directive:"));
            loggerCallback(directive);
            string project = string.Empty;
            string objectType = string.Empty;
            string uid = string.Empty;
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(directive);

            try
            {
                project = xDoc.DocumentElement.Attributes["project"].Value;
            }
            catch (Exception)
            {
                this.LogAndEmail("EA Plugin, project attribute missing on plugin element");
                CogUtility.SetStatusCode(ref ret, ProcessStatusCode.HadUnrecoverableErrors);
            }

            try
            {

                objectType = xDoc.DocumentElement.Attributes["objectType"].Value;
                if (!this.IsKnownEntityType(objectType))
                {
                    this.LogAndEmail(string.Format("EA Plugin, warning: objectType parameter has unknown value {0}. Expected one of the following values: {1}.", objectType, string.Join(", ", knownEntityTypes)));
                    CogUtility.SetStatusCode(ref ret, ProcessStatusCode.IssuedWarnings);
                }

            }
            catch (Exception)
            {

                this.LogAndEmail("EA Plugin, objectType attribute missing on plugin element");
                CogUtility.SetStatusCode(ref ret, ProcessStatusCode.HadUnrecoverableErrors);
            }

            try
            {
                uid = xDoc.DocumentElement.Attributes["uid"].Value;

            }
            catch (Exception)
            {
                this.LogAndEmail("EA Plugin, uid attribute missing on plugin element");
                CogUtility.SetStatusCode(ref ret, ProcessStatusCode.HadUnrecoverableErrors);
            }


            XmlElement xPlugin = xDoc.SelectSingleNode(string.Format("./{0}", this.pluginNumber)) as XmlElement;
            HashSet<string> includedData = new HashSet<string>();
            Dictionary<string, string> cockpitFieldTypes = new Dictionary<string, string>();
            foreach (XmlElement xData in xPlugin.SelectNodes("./data"))
            {
                includedData.Add(xData.GetAttribute("name").ToLower());
                cockpitFieldTypes[xData.GetAttribute("name")] = xData.GetAttribute("type").ToLower();
            }

            #region DataTarget
            //Data is being exported from cockpit to EA
            if (isTarget)
            {
                XmlDocument xDirective = new XmlDocument();
                xDirective.LoadXml(directive);
                string value = null;
                objectType = xDirective.SelectSingleNode(string.Format("./{0}", this.pluginNumber)).Attributes[0].Value;
                XmlDocument xValueData = new XmlDocument();
                xValueData.LoadXml(valueData);
                foreach (XmlElement xItem in xValueData.SelectNodes("./data/item"))
                {
                    uid = xItem.GetAttribute("uid");
                    string cockpitObjectType = GetCockpitTypeFromEAType(objectType);
                    foreach (XmlElement xValue in xItem.SelectNodes("./value"))
                    {
                        string name = xValue.GetAttribute("name");
                        //get the cockpit equivaluent of objectType
                        string eAFieldName = GetEAFieldFromCockpitField(cockpitObjectType, objectType, name);
                        if (!string.IsNullOrEmpty(eAFieldName))
                        {
                            value = xValue.InnerText;
                        }
                    }
                    string parentID = null;
                    try
                    {
                        CogUtility.SetStatusCode(ref ret, this.GetParentId(project, objectType, uid, out parentID, out string xmlResponse));
                        if (!string.IsNullOrEmpty(parentID))
                        {
                            EAClient eAclient = this.eaClient;
                            XDocument doc = UpdateEAResource(xmlResponse, parentID, value);
                            string url = "/oslc/am/pu/resource/";
                            string responseXML = null;
                            string conString = project + url;
                            //System.Diagnostics.Debug.Write(sb.ToString());
                            using (HttpWebResponse response = eAclient.UpdateEA(conString, doc.ToString(), "POST", true))
                            {
                                this.LogAndEmail("EA Plugin, Update Resources successfully");
                                responseXML = GetResponseXmlString(response);
                                ret = ProcessStatusCode.Successful;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        this.LogAndEmail(string.Format("EA Plugin, Update failed", ex.Message));
                        ret = ProcessStatusCode.HadUnrecoverableErrors;
                    }

                }
            }
            #region DataSource
            //Data is being passed from  Azure DevOps to cockpit
            else
            {
                string rootName = string.Empty;
                try
                {
                    if (xDoc.DocumentElement.Attributes["rootName"] != null)
                    {
                        if (!string.IsNullOrEmpty(xDoc.DocumentElement.Attributes["rootName"].Value))
                        {
                            rootName = xDoc.DocumentElement.Attributes["rootName"].Value;
                        }
                    }
                }
                catch (Exception)
                {
                    this.LogAndEmail("EA Plugin, rootId attribute missing on plugin element");
                    CogUtility.SetStatusCode(ref ret, ProcessStatusCode.HadUnrecoverableErrors);
                }

                string directiveUid = xPlugin.GetAttribute("uid");
                objectType = xPlugin.GetAttribute("objectType");
                //Set the value data appropriately
                CogUtility.SetStatusCode(ref ret, this.GetValueDataFromEAData(objectType, includedData, cockpitFieldTypes, ref valueData, directiveUid, rootName, project));
            }
            #endregion
            return ret;
        }

        private XDocument UpdateEAResource(string GetResponse, string parentID,string value)
        {
            XDocument doc = XDocument.Parse(GetResponse);
            StringBuilder sb = new StringBuilder();
            XmlWriterSettings xws = new XmlWriterSettings();
            xws.OmitXmlDeclaration = true;
            xws.Indent = true;

            using (XmlWriter xw = XmlWriter.Create(sb, xws))
            {
                XNamespace ns1 = "http://open-services.net/ns/am#";
                XNamespace ns2 = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
                XNamespace ns3 = "http://purl.org/dc/terms/";
                XNamespace ns4 = "http://xmlns.com/foaf/0.1/";
                XNamespace ns5 = "http://www.sparxsystems.com.au/oslc_am#";
                doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"));
                XElement reportElement = new XElement(ns2 + "RDF",
                    new XAttribute(XNamespace.Xmlns + "oslc_am", ns1),
                    new XAttribute(XNamespace.Xmlns + "rdf", ns2),
                    new XAttribute(XNamespace.Xmlns + "dcterms", ns3),
                    new XAttribute(XNamespace.Xmlns + "foaf", ns4),
                    new XAttribute(XNamespace.Xmlns + "ss", ns5));
                doc.Add(reportElement);
                reportElement.Add(new XElement(ns1 + "Resource",
                    new XElement(ns3 + "identifier", parentID), new XElement(ns3 + "description", value)));
                doc.WriteTo(xw);
            }
            return doc;
        }

        private ProcessStatusCode GetValueDataFromEAData(string objectType, HashSet<string> includedData, Dictionary<string, string> cockpitFieldTypes, ref string valueData, string directiveUid,string rootName,string project)
        {
            ProcessStatusCode ret = ProcessStatusCode.Successful;
            string parentID = null;
            this.GetParentId(project, objectType, rootName, out parentID, out string GetResponse);
            string getResponse = null;
            try
            {
                //Get Nested resources By Id
                CogUtility.SetStatusCode(ref ret, GetNestedresourcesByParentid(project, objectType, ref parentID, out getResponse));
                XDocument doc = XDocument.Parse(getResponse);
                XElement node = (XElement)doc.FirstNode;
                XNamespace name = node.GetNamespaceOfPrefix("rdfs");
                IEnumerable<XElement> member = node.Descendants(name + "member");

                foreach (XElement temp in member)
                {
                    bool nested = false;
                    string parentName = null;
                    string parenroottID = selectNodeDetailsSource(temp, association, nested, parentName);
                }
            }
            catch (Exception ex)
            {
                this.LogAndEmail(string.Format("EA Plugin, server returned invalid response xml\r\nError:{0}", getResponse));
                return ProcessStatusCode.HadUnrecoverableErrors;
            }
            XmlDocument xDoc = new XmlDocument();
            XmlDeclaration xDec = xDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement xData = xDoc.CreateElement("data");
            xData.SetAttribute("type", "value");
            xDoc.AppendChild(xData);
            xDoc.InsertBefore(xDec, xData);
            string sObjectType = objectType.ToLower();
            string cockpitObjectType = GetCockpitTypeFromEAType(objectType);
            foreach (KeyValuePair<string, rdfObject> item in association)
            {
                Dictionary<string, string> eAFieldMapping = new Dictionary<string, string>();
                string key = item.Key;
                rdfObject value = item.Value;
                eAFieldMappingbyrdfobject(value, eAFieldMapping);
                if (value.type.ToLower().Equals(sObjectType))
                {
                    //Create item in member xml
                    XmlElement xItem = xDoc.CreateElement("item");
                    string eaValue = GetEAFieldValueByUid(directiveUid, eAFieldMapping);
                    xItem.SetAttribute("uid", eaValue);
                    foreach (string fieldName in cockpitFieldTypes.Keys)
                    {
                        XmlElement xValue = xDoc.CreateElement("value");
                        xValue.SetAttribute("name", fieldName);
                        xValue.SetAttribute("type", cockpitFieldTypes[fieldName]);
                        object eavalue = GetValueByField(value, fieldName);
                        if (!string.IsNullOrEmpty(value.parentUid))
                        {
                            //skip            xItem.SetAttribute("parentUid", value.parentUid);
                            //skip            xItem.SetAttribute("parentType", "directories");
                        }
                        xValue.InnerText = eavalue.ToString();
                        xItem.AppendChild(xValue);
                    }
                    xData.AppendChild(xItem);

                }
                valueData = xDoc.OuterXml;
            }
           
            return ret;
        }

        private object GetValueByField(rdfObject data, string fieldName)
        {
            object value = null;
            switch (fieldName)
            {
                case "notes":
                    value = data.description;
                    break;
                case "identifier":
                    value = data.identifier;
                    break;
                case "title":
                    value = data.title;
                    break;
                default:
                    this.LogAndEmail("Invalid field passed to set  Object. Ignoring this field");
                    break;
            }
            return value;
        }
        private string GetCockpitFieldFromJiraField(string source, string target, string jiraField)
        {
            string cockpitField = null;
            //walk through the tree with source lookup,  target lookup and jiraField field match
            if (cockpitEADataMapping.ContainsKey(source))
            {
                Dictionary<string, Dictionary<string, object>> targetMapping = cockpitEADataMapping[source];
                if (targetMapping.ContainsKey(target))
                {
                    Dictionary<string, object> dataMapping = targetMapping[target];
                    if (dataMapping.ContainsValue(jiraField))
                    {
                        foreach (var mapping in dataMapping)
                        {
                            if (jiraField.Equals(mapping.Value))
                            {
                                cockpitField = mapping.Key;
                                break;
                            }
                        }
                    }
                }
            }
            return cockpitField;
        }

            private string GetEAFieldFromCockpitField(string source, string target, string cockpitField)
        {

            string eAField = null;
            //walk through the tree with source lookup,  target lookup and cockpit field match
            if (cockpitEADataMapping.ContainsKey(source))
            {
                Dictionary<string, Dictionary<string, object>> targetMapping = cockpitEADataMapping[source];
                if (targetMapping.ContainsKey(target))
                {
                    Dictionary<string, object> dataMapping = targetMapping[target];
                    if (dataMapping.ContainsKey(cockpitField))
                    {
                       eAField = (string)dataMapping[cockpitField];
                    }
                }
            }
            return eAField;
        }

        private string GetCockpitTypeFromEAType(string EAType)
        {
            string cockpitType = null;
            foreach (string itemKey in this.cockpitEADataMapping.Keys)
            {
                Dictionary<string, Dictionary<string, object>> value = cockpitEADataMapping[itemKey];
                if (value.ContainsKey(EAType))
                {
                    cockpitType = itemKey;
                    break;
                }
            }
            return cockpitType;
        }

        private void GetPackageID(XDocument doc, string uid, ref string pkID)
        {
            XElement node = (XElement)doc.FirstNode;
            XNamespace name = node.GetNamespaceOfPrefix("rdfs");
            IEnumerable<XElement> member = node.Descendants(name + "member");
            foreach (XElement temp in member)
            {

                rdfObject rdf = selectNode(temp);
                if (rdf.title.ToLower() == (uid.ToLower()))
                {
                    pkID = rdf.identifier;

                }
                if (pkID != null)
                {
                    break;
                }
            }
        }
        private void LogAndEmail(string message)
        {
            this.loggerCallback(message);
            this.notifyCallback(message);

        }
        private bool IsKnownEntityStereoType(string objectType)
        {
            return knownEntityStereoTypes.Contains(objectType);
        }
        public static string[] knownEntityStereoTypes = new string[]
       {
            "CockpitDocument", "CockpitSection","CockpitFolder","requirements"
       };
        private bool IsKnownEntityType(string objectType)
        {
            return knownEntityTypes.Contains(objectType);
        }
        public static string[] knownEntityTypes = new string[]
       {
            "Package", "Requirement"
       };
        /// <summary>
        /// Sorts a list of membership data so that parents are before their children.
        /// This ensures that parents will be created before their children.
        /// </summary>
        /// <param name="xmlNodeList">Membership data</param>
        /// <returns>Sorted list of membership data</returns>
        private List<XmlNode> ParentSort(XmlNodeList xmlNodeList)
        {
            List<XmlNode> retval = new List<XmlNode>();
            List<XmlNode> inputList = new List<XmlNode>();

            //Put the node list into an actual list to use insert and remove operations
            foreach (XmlNode node in xmlNodeList)
            {
                inputList.Add(node);
            }

            retval = inputList.OrderBy(x => GetDepth(inputList, x)).ToList();
            //foreach (XmlNode x in retval) { Console.WriteLine(x.OuterXml); }
            return retval;
        }
        /// <summary>
        /// Recursively calculates the depth of an item based on it's parents
        /// </summary>
        /// <param name="list">List of items</param>
        /// <param name="node">Node to find depth of</param>
        /// <returns>Depth of node</returns>
        private static int GetDepth(List<XmlNode> list, XmlNode node)
        {
            //If the depth turns out to be
            int depth = 0;

            //If the node does not have a precomputed depth and it has a parent, recursively figure out it's depth
            if (node != null && node.Attributes["depth"] == null && node.Attributes["parentUid"] != null)
            {
                //We don't need to check types since we can only create objects of one type, the type of the parent shouldn't matter.
                //Worst case (name collision) object might be created later than it needs to be, but won't hurt anything.
                depth = GetDepth(list, list.FirstOrDefault<XmlNode>(x => x.Attributes["uid"].Value.Equals(node.Attributes["parentUid"].Value))) + 1;
                XmlAttribute attr = new XmlDocument().CreateAttribute("depth");
                attr.Value = depth.ToString();
                node.Attributes.SetNamedItem(attr);
            }
            else if (node != null && node.Attributes["depth"] != null) //Get the precomputed depth and return that
            {
                depth = Convert.ToInt32(node.Attributes["depth"].Value);
            }

            return depth;
        }
        public ProcessStatusCode ProcessMembers(bool isTarget, string directive, ref string memberData)
        {
            this.loggerCallback(string.Format("EA Plugin, ProcessMembers run with directive:\r\n{0}", directive));
            ProcessStatusCode currentStatus = ProcessStatusCode.Successful;
            //Get basic information from the directives
            XmlDocument directivesDoc = new XmlDocument();
            directivesDoc.LoadXml(directive);
            string domain = string.Empty;
            string project = string.Empty;
            string objectType = string.Empty;
            string stereoType = string.Empty;
            string directiveParentUID = string.Empty;
            string directiveUID = string.Empty;
            string ParentUID = string.Empty;
            string uid = string.Empty;
            string defaultParentId = string.Empty;
            string defaultParentKey = string.Empty;
            try
            {
                project = directivesDoc.DocumentElement.Attributes["project"].Value;
            }
            catch (Exception)
            {
                this.LogAndEmail("EA Plugin, project attribute missing on plugin element");
                CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
            }
            try
            {
                objectType = directivesDoc.DocumentElement.Attributes["objectType"].Value;
                if (!this.IsKnownEntityType(objectType))
                {
                    this.LogAndEmail(string.Format("EA Plugin, warning: objectType parameter has unknown value {0}. Expected one of the following values: {1}.", objectType, string.Join(", ", knownEntityTypes)));
                    CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.IssuedWarnings);
                }
            }
            catch (Exception)
            {

                this.LogAndEmail("EA Plugin, objectType attribute missing on plugin element");
                CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
            }
            try
            {
                if (directivesDoc.DocumentElement.Attributes["stereotype"] != null)
                {
                    stereoType = directivesDoc.DocumentElement.Attributes["stereotype"].Value;
                    if (!this.IsKnownEntityStereoType(stereoType))
                    {
                        this.LogAndEmail(string.Format("EA Plugin, warning: stereoType parameter has unknown value {0}. Expected one of the following values: {1}.", objectType, string.Join(", ", knownEntityStereoTypes)));
                        CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.IssuedWarnings);
                    }
                }
            }
            catch (Exception)
            {

                this.LogAndEmail("EA Plugin, objectType attribute missing on plugin element");
                CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
            }

            try
            {
                directiveUID = directivesDoc.DocumentElement.Attributes["uid"].Value;

            }
            catch (Exception)
            {
                this.LogAndEmail("EA Plugin, uid attribute missing on plugin element");
                CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
            }

            try
            {
                directiveParentUID = directivesDoc.DocumentElement.Attributes["parentUid"].Value;
            }
            catch (Exception)
            {
                //Default is to use the same as the normal uid
                directiveParentUID = directiveUID;
            }

            //If parsing of the initial directive attributes failed, get out of here
            if (currentStatus == ProcessStatusCode.HadUnrecoverableErrors)
            {
                return currentStatus;
            }

            #region MembershipTarget
            if (isTarget)
            {
                string defaultParentUid = directivesDoc.DocumentElement.Attributes["defaultParent"] != null ? directivesDoc.DocumentElement.Attributes["defaultParent"].Value : null;
                string parentTypeMappingKey = null;
                string parentID = null;
                try
                {
                    parentTypeMappingKey = directivesDoc.DocumentElement.Attributes["parentTypeMapping"].Value;
                }
                catch (Exception)
                {
                    this.LogAndEmail("EA Plugin, parentTypeMapping attribute missing on plugin element, assuming direct map");
                }

                //Load the rules for what to do from the directives file
                RuleAction missing = RuleAction.Ignore;
                RuleAction excess = RuleAction.Ignore;
                XmlNodeList missingDirectiveList = directivesDoc.SelectNodes("//rule[@type='missing']");
                if (missingDirectiveList != null && missingDirectiveList.Count == 1)
                {
                    missing = this.ParseRule(missingDirectiveList[0]);
                }
                else
                {
                    CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
                    this.LogAndEmail("EA Plugin, required rule of type \"missing\" is not specified or has duplicates, aborting");
                    return currentStatus;
                }

                XmlNodeList excessDirectiveList = directivesDoc.SelectNodes("//rule[@type='excess']");
                if (excessDirectiveList != null && excessDirectiveList.Count == 1)
                {
                    excess = this.ParseRule(excessDirectiveList[0]);
                }
                else
                {
                    CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
                    this.LogAndEmail("EA Plugin, required rule of type \"excess\" is not specified or has duplicates, aborting");
                    return currentStatus;
                }
                XmlDocument memberDoc = new XmlDocument();
                memberDoc.LoadXml(memberData);
                //Sort the items so parents are created before children
                List<XmlNode> memberItems = this.ParentSort(memberDoc.SelectNodes("data/item"));
                List<string> memberItemUIDs = new List<string>();
                foreach (XmlNode item in memberItems)
                {
                    string rootName = string.Empty;
                    
                    //Track the UID and parentUID in case we need to delete excess
                    uid = null;
                    if (item.Attributes["uid"] != null)
                    {
                        uid = item.Attributes["uid"].Value;
                        memberItemUIDs.Add(item.Attributes["uid"].Value);
                        if (string.IsNullOrEmpty(item.Attributes["uid"].Value))
                        {
                            this.LogAndEmail(string.Format(" uid value Empty {0}", item.Attributes["uid"].Value));
                            continue;
                        }
                    }
                    try
                    {
                        if (directivesDoc.DocumentElement.Attributes["rootName"] != null)
                        {
                            if (!string.IsNullOrEmpty(directivesDoc.DocumentElement.Attributes["rootName"].Value))
                            {
                                rootName = directivesDoc.DocumentElement.Attributes["rootName"].Value;
                            }
                        }
                    }
                    catch (Exception)
                    {
                        this.LogAndEmail("EA Plugin, rootId attribute missing on plugin element");
                        CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
                    }

                    if (item.Attributes["parentUid"] != null)
                    {
                        if (string.IsNullOrEmpty(item.Attributes["parentUid"].Value))
                        {
                            this.LogAndEmail(string.Format(" parentUid value Empty {0}", item.Attributes["parentUid"].Value));
                            //continue;
                        }
                        memberItemUIDs.Add(item.Attributes["parentUid"].Value);
                    }
                    //If there is a parent specified, validate that it is there
                    string parentType = item.Attributes["parentType"] == null ? objectType : item.Attributes["parentType"].Value;
                    CogUtility.SetStatusCode(ref currentStatus, this.ApplyParentTypeMapping(parentTypeMappingKey, ref parentType));
                    if (currentStatus == ProcessStatusCode.HadUnrecoverableErrors)
                    {
                        return currentStatus;
                    }
                    ((XmlElement)item).SetAttribute("parentType", parentType);
                    if (!string.IsNullOrEmpty(parentType))
                    {
                        foreach (var mapping in eATypeMapping)
                        {
                            if (mapping.Key.Contains(parentType.ToLower()))
                            {
                                parentType = mapping.Value;
                            }
                        }

                        if (!string.IsNullOrEmpty(parentType))
                        {
                            string directiveparentType = null;
                            if (directivesDoc.DocumentElement.Attributes["parentType"] != null)
                            {
                                directiveparentType = directivesDoc.DocumentElement.Attributes["parentType"].Value;
                            }
                            if (string.IsNullOrEmpty(rootName) || (item.Attributes["parentType"].Value.ToLower().Equals(directiveparentType)))
                            {
                                if (item.Attributes["parentUid"] != null)
                                {
                                    if (!string.IsNullOrEmpty(item.Attributes["parentUid"].Value))
                                    {
                                        rootName = item.Attributes["parentUid"].Value;
                                    }
                                }
                            }
                            CogUtility.SetStatusCode(ref currentStatus, this.GetParentId(project, objectType, rootName, out parentID, out string response));
                            if (currentStatus == ProcessStatusCode.HadUnrecoverableErrors)
                            {
                                this.LogAndEmail(string.Format("EA Plugin, failed to get parent ID  rootName {0}", rootName));
                                return ProcessStatusCode.HadUnrecoverableErrors;
                            }
                            else if (string.IsNullOrEmpty(parentID))
                            {
                                //Could not locate parent, use defaultParent if available, or ignore it otherwise
                                CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.IssuedWarnings);
                                if (!string.IsNullOrEmpty(defaultParentKey))
                                {
                                    this.LogAndEmail(string.Format("EA Plugin, failed to find parent with UID {0} and type {1} for entity with uid {2}. Using default parent instead.", item.Attributes["parentUid"].Value, item.Attributes["parentType"].Value, item.Attributes["uid"].Value));
                                    parentID = defaultParentKey;
                                }
                                else
                                {

                                    this.LogAndEmail(string.Format("EA Plugin, failed to find parent with UID {0} and type {1} for entity with uid {2}. No default parent specified so ignoring parent information.", item.Attributes["parentUid"].Value, item.Attributes["parentType"].Value, item.Attributes["uid"].Value));
                                }
                            }
                            else
                            {
                                this.LogAndEmail(string.Format("EA Plugin,parent ID {0} for entity with uid {1}", item.Attributes["parentUid"].Value, item.Attributes["uid"].Value));
                            }
                        }
                    }
                    //Check if the item itself already exists
                    if (string.IsNullOrEmpty(uid))
                    {
                        this.LogAndEmail(string.Format("EA Plugin, item itself already exists {0}", uid));
                        continue;

                    }
                    string getResponse = null;
                    rdfObject rdfobject = new rdfObject();
                    List<string> pkCount = new List<string>();

                    try
                    {
                        CogUtility.SetStatusCode(ref currentStatus, GetNestedresourcesByParentid(project, objectType, ref parentID, out getResponse));
                        XDocument doc = XDocument.Parse(getResponse);
                        rdfobject = GetResourceByName(directivesDoc, doc, item, uid, project, rootName, ref parentID);
                        if (!string.IsNullOrEmpty(rdfobject.identifier))
                        {
                            pkCount.Add(rdfobject.identifier);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.LogAndEmail(string.Format("EA Plugin, server returned invalid response xml\r\nError:{0}", ex.Message));
                        return ProcessStatusCode.HadUnrecoverableErrors;
                    }
                    //Create it with default values and parent (if parent is specified) if it does not already exist and rules allow for it
                    if (missing == RuleAction.Create && pkCount.Count == 0)
                    {
                        try
                        {
                            this.LogAndEmail(string.Format("creating Name with uid={0}, resourcesType={1}", uid, objectType));
                            CogUtility.SetStatusCode(ref currentStatus, CreateResource(project, objectType, uid, stereoType, ref parentID, out string responseXML));

                            //List of cockpit Items in EA plugin
                            if (this.listofItemsEa.Contains(directiveUID))
                            {
                                CreateResourceTaggededValue(responseXML, uid, project);
                            }
                        }
                        catch (WebException ex)
                        {
                            this.loggerCallback(string.Format("StatusCode:{0},Error:{1},Url:{2}", ((HttpWebResponse)ex.Response).StatusCode, ex.Message, ex.Response.ResponseUri));
                            currentStatus = ProcessStatusCode.HadUnrecoverableErrors;
                            return currentStatus;
                        }

                        catch (Exception ex)
                        {
                            this.LogAndEmail(string.Format("Error:\r\n{0}", ex.Message));
                            currentStatus = ProcessStatusCode.HadUnrecoverableErrors;
                            return currentStatus;
                        }
                    }
                    //If the directives say to remove excess, get the excess elements and delete them && excess == RuleAction.Remove)
                    if (pkCount.Count > 0)
                    {
                        foreach (string resp in pkCount)
                        {
                            try
                            {
                                //this.loggerCallback(string.Format("Deleting with Name={0}, Package={1}", uid, objectType));
                                //CogUtility.SetStatusCode(ref currentStatus, DeletePackage(project, pkID));

                            }
                            catch (WebException ex)
                            {

                                this.LogAndEmail(string.Format("StatusCode:{0}, Error:{1}, Url:{2}", ((HttpWebResponse)ex.Response).StatusCode, ex.Message, ex.Response.ResponseUri));
                                currentStatus = ProcessStatusCode.HadUnrecoverableErrors;
                                return currentStatus;
                            }

                            catch (Exception ex)
                            {
                                this.LogAndEmail(string.Format("Error:\r\n{0}", ex.Message));
                                currentStatus = ProcessStatusCode.HadUnrecoverableErrors;
                                return currentStatus;
                            }
                        }
                        // this.LogAndEmail(string.Format("creating workitem with uid={0}, Packagename={1}", uid, objectType));
                        //  CogUtility.SetStatusCode(ref currentStatus, CreatePackage(project, objectType, rootId, uid, ref parentID, pkID));

                    }

                }

            }
            #endregion
            #region MemberSource
            //Need to create member xml for cockpit plugin to process
            else
            {
                loggerCallback(string.Format("EA Plugin, ProcessMembers run with directive:"));
                loggerCallback(directive);
                string parentID = null;
                XmlDocument xDirective = new XmlDocument();
                xDirective.LoadXml(directive);
                string rootName = string.Empty;
                try
                {
                    if (xDirective.DocumentElement.Attributes["rootName"] != null)
                    {
                        if (!string.IsNullOrEmpty(xDirective.DocumentElement.Attributes["rootName"].Value))
                        {
                            rootName = xDirective.DocumentElement.Attributes["rootName"].Value;
                        }
                    }
                }
                catch (Exception)
                {
                    this.LogAndEmail("EA Plugin, rootId attribute missing on plugin element");
                    CogUtility.SetStatusCode(ref currentStatus, ProcessStatusCode.HadUnrecoverableErrors);
                }
                // Dictionary<string, rdfObject> association = new Dictionary<string, rdfObject>();

                CogUtility.SetStatusCode(ref currentStatus, this.GetParentId(project, objectType, rootName, out parentID, out string response));
                string getResponse = null;
                try
                {
                    CogUtility.SetStatusCode(ref currentStatus, GetNestedresourcesByParentid(project, objectType, ref parentID, out getResponse));
                    XDocument doc = XDocument.Parse(getResponse);
                    XElement node = (XElement)doc.FirstNode;
                    XNamespace name = node.GetNamespaceOfPrefix("rdfs");
                    IEnumerable<XElement> member = node.Descendants(name + "member");
                    foreach (XElement temp in member)
                    {
                        bool nested = false;
                        string parentName = null;
                        string parenroottID = selectNodeDetailsSource(temp, association, nested, parentName);
                    }

                }
                catch (Exception ex)
                {
                    this.LogAndEmail(string.Format("EA Plugin, server returned invalid response xml\r\nError:{0}", getResponse));
                    return ProcessStatusCode.HadUnrecoverableErrors;
                }

                XmlElement xPlugin = xDirective.SelectSingleNode(string.Format("./{0}", this.pluginNumber)) as XmlElement;
                if (xPlugin == null)
                {
                    this.loggerCallback("EA Plugin, no plugin directives specified for member task");
                    return ProcessStatusCode.HadUnrecoverableErrors;
                }

                string sObjectType = xPlugin.GetAttribute("objectType").ToLower();

                //Setup member data document
                XmlDocument xDoc = new XmlDocument();
                XmlDeclaration xDec = xDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
                XmlElement xData = xDoc.CreateElement("data");
                xData.SetAttribute("type", "member");
                xDoc.AppendChild(xData);
                xDoc.InsertBefore(xDec, xData);
                //defaultParentKey = xPlugin.GetAttribute("defaultParent");
                //string parentUid = xPlugin.GetAttribute("parentUid");
                foreach (KeyValuePair<string, rdfObject> item in association)
                {
                    Dictionary<string, string> eAFieldMapping = new Dictionary<string, string>();
                    string key = item.Key;
                    rdfObject value = item.Value;
                    eAFieldMappingbyrdfobject(value, eAFieldMapping);
                    if (value.type.ToLower().Equals(sObjectType))
                    {
                        //Create item in member xml 
                        XmlElement xItem = xDoc.CreateElement("item");
                        string eaValue = GetEAFieldValueByUid(directiveUID, eAFieldMapping);
                        xItem.SetAttribute("uid", eaValue);
                        xData.AppendChild(xItem);
                    }
                }
                memberData = xDoc.OuterXml;
                currentStatus = ProcessStatusCode.Successful;
            }
            #endregion
            //If parsing of the initial directive attributes failed, get out of here
            return currentStatus;

        }

        private void eAFieldMappingbyrdfobject(rdfObject item,Dictionary<string,string> eAFieldMapping)
        {
            PropertyInfo[] infos = item.GetType().GetProperties();
            foreach (PropertyInfo info in infos)
            {
                if (info.GetValue(item, null) != null)
                {
                    eAFieldMapping.Add(info.Name, info.GetValue(item, null).ToString());
                }
            }
        }

        private string GetEAFieldValueByUid(string directiveUID, Dictionary<string, string> eAFieldMapping)
        {
            string eAValue = null;
            foreach (string item in eAFieldMapping.Keys)
            {
                if (item.Contains(directiveUID))
                {
                   eAValue = eAFieldMapping[item];
                   break;
                    
                }

            }
            return eAValue;
        }

        private void CreateResourceTaggededValue(string responseXML,string uid,string project)
        {
            string resourceIdentifier = null;
            EAClient Eaclient = this.eaClient;
            XDocument doc1 = XDocument.Parse(responseXML);
            XElement node = (XElement)doc1.FirstNode;
            XNamespace oslc_am = node.GetNamespaceOfPrefix("oslc_am");
            XNamespace getNamespaceOfPrefixrdf = node.GetNamespaceOfPrefix("rdf");
            var result = (from temp1 in node.Descendants(oslc_am + "Resource")
                          select node).ToList();
            if (result.Count != 0)
            {
                IEnumerable<XElement> elements = node.Descendants(oslc_am + "Resource");
                foreach (XElement item in elements)
                {
                    resourceIdentifier = item.Attribute(getNamespaceOfPrefixrdf + "about").Value;

                }
                string startWith = "resource/";
                string endWith = "/";
                int start = resourceIdentifier.IndexOf(startWith) + startWith.Length;
                int end = resourceIdentifier.IndexOf(endWith, start); //Start after the index of 'my' since 'is' appears twice
                resourceIdentifier = resourceIdentifier.Substring(start, end - start);
            }
            if (!string.IsNullOrEmpty(resourceIdentifier))
            {
                this.LogAndEmail(string.Format("Create Resource TaggededValue resourceIdentifier={0}", resourceIdentifier));
                string url = "/oslc/am/cf/taggedvalue/";
                string conString = project + url;
                StringBuilder sb = new StringBuilder();
                XmlWriterSettings xws = new XmlWriterSettings();
                xws.OmitXmlDeclaration = true;
                xws.Indent = true;
                XDocument doc = null;
                using (XmlWriter xw = XmlWriter.Create(sb, xws))
                {
                    XNamespace ns1 = "http://open-services.net/ns/am#";
                    XNamespace ns2 = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
                    XNamespace ns3 = "http://purl.org/dc/terms/";
                    XNamespace ns4 = "http://xmlns.com/foaf/0.1/";
                    XNamespace ns5 = "http://www.sparxsystems.com.au/oslc_am#";
                    doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"));
                    XElement reportElement = new XElement(ns2 + "RDF",
                        new XAttribute(XNamespace.Xmlns + "oslc_am", ns1),
                        new XAttribute(XNamespace.Xmlns + "rdf", ns2),
                        new XAttribute(XNamespace.Xmlns + "dcterms", ns3),
                        new XAttribute(XNamespace.Xmlns + "foaf", ns4),
                        new XAttribute(XNamespace.Xmlns + "ss", ns5));
                    doc.Add(reportElement);
                    reportElement.Add(new XElement(ns5 + "taggedvalue",
                            new XElement(ns3 + "title", "Cockpit ItemId"), new XElement(ns5 + "type", "Type=String;"), new XElement(ns5 + "resourceidentifier", resourceIdentifier), new XElement(ns5 + "value",uid)));
                    doc.WriteTo(xw);
                }
                using (HttpWebResponse response1 = Eaclient.CreateResources(conString, doc.ToString(), "POST", true))
                {
                    this.LogAndEmail(string.Format("Created Resource TaggededValue successfully : resourceIdentifier={0}", resourceIdentifier));
                    responseXML = GetResponseXmlString(response1);
                    // parentID = null;
                    // return result;
                }
            }

        }


        private string selectNodeDetailsSource(XElement temp, Dictionary<string, rdfObject> test, bool nestedresources, string name)
        {
            string pkID = null;
            rdfObject rdf = new rdfObject();
            //rdf.parentUid = name;
            //getobject(temp, rdf);
            rdf = selectNode(temp);
            if (nestedresources && !string.IsNullOrEmpty(name))
            {
                rdf.parentUid = name;
            }
            if (!test.ContainsKey(rdf.title))
            {
                test.Add(rdf.title, rdf);
            }
            else
            {
                test[rdf.title] = rdf;
            }
           /* //level 2
            if (rdf.nestedresources != null)
            {
                EAClient eA = this.eaClient;
                //string url = "/oslc/am/nestedresources/";
                using (HttpWebResponse response = eA.GetNestedResources(null, string.Empty, "GET", true, rdf.nestedresources))
                {
                    nestedresources = true;
                    string responseXML = GetResponseXmlString(response);
                    IEnumerable<XElement> member = selectMember(responseXML);
                    foreach (XElement temp1 in member)
                    {
                        string parentname = rdf.title;
                        // string parenroottID = selectChildNodeDetails(temp1, level2, level1, parentname);
                        string parenroottID = selectNodeDetailsSource(temp1, test, nestedresources, parentname);

                    }
                }
            }
            else
            {
                nestedresources = false;
            }
            */

            //  firstNode.Descendants(getNamespaceOfPrefix + "type");
            return pkID;
        }

        private static void getobject(XElement temp, rdfObject rdf)
        {
            XElement firstNode = (XElement)temp.FirstNode;
            XNamespace getNamespaceOfPrefix = firstNode.GetNamespaceOfPrefix("dcterms");
            XNamespace getNamespaceOfPrefixss = firstNode.GetNamespaceOfPrefix("ss");
            XNamespace getNamespaceOfPrefixrdf = firstNode.GetNamespaceOfPrefix("rdf");
            var result = (from temp1 in temp.Descendants(getNamespaceOfPrefixss + "nestedresources")
                          select temp).ToList();
            rdf.title = firstNode.Descendants(getNamespaceOfPrefix + "title").FirstOrDefault().Value;
            string parentname = rdf.title;
            rdf.type = firstNode.Descendants(getNamespaceOfPrefix + "type").FirstOrDefault().Value;
            rdf.identifier = firstNode.Descendants(getNamespaceOfPrefix + "identifier").FirstOrDefault().Value;
            List<string> child = new List<string>();
            //check count if collection contains nestedresources
            if (result.Count != 0)
            {
                IEnumerable<XElement> elements = firstNode.Descendants(getNamespaceOfPrefixss + "nestedresources");
                foreach (XElement submenu in elements)
                {
                    rdf.nestedresources = submenu.Attribute(getNamespaceOfPrefixrdf + "resource").Value;

                }
            }
        }

        private static IEnumerable<XElement> selectMember(string responseXML)
        {
            XDocument doc = XDocument.Parse(responseXML);
            XElement node = (XElement)doc.FirstNode;
            XNamespace name = node.GetNamespaceOfPrefix("rdfs");
            IEnumerable<XElement> member = node.Descendants(name + "member");
            return member;
        }
      

        private string selectNodeDetails(XDocument doc, XElement temp)
        {
            string pkID = null;
            rdfObject rdf = new rdfObject();
            XElement firstNode = (XElement)temp.FirstNode;
            XNamespace getNamespaceOfPrefix = firstNode.GetNamespaceOfPrefix("dcterms");
            XNamespace getNamespaceOfPrefixss = firstNode.GetNamespaceOfPrefix("ss");
            rdf.title = firstNode.Descendants(getNamespaceOfPrefix + "title").FirstOrDefault().Value;
            rdf.type = firstNode.Descendants(getNamespaceOfPrefix + "type").FirstOrDefault().Value;
            rdf.identifier = firstNode.Descendants(getNamespaceOfPrefix + "identifier").FirstOrDefault().Value;
            rdf.nestedresources= firstNode.Descendants(getNamespaceOfPrefixss + "nestedresources").FirstOrDefault().Value;
            //var elementsWithHeader = firstNode.Descendants(getNamespaceOfPrefixss + "nestedresources");


            firstNode.Descendants(getNamespaceOfPrefix + "type");
            //ParentUID = ParentUID.Replace(" ", string.Empty);
           // if (rdf.title.ToLower() == (ParentUID.ToLower()))
           // {
            //    pkID = rdf.identifier;

          //  }
            return pkID;
        }

        private rdfObject GetResourceByName(XmlDocument directive, XDocument doc, XmlNode xmlNode, string uidName, string project, string rootId, ref string parentID)
        {
            XElement node = (XElement)doc.FirstNode;
            XNamespace name = node.GetNamespaceOfPrefix("rdfs");
            IEnumerable<XElement> member = node.Descendants(name + "member");
            List<rdfObject> rdflist = new List<rdfObject>();
            rdfObject rdf = new rdfObject();
            foreach (XElement temp in member)
            {
                rdflist.Add(selectNode(temp));
            }
            List<rdfObject> result = rdflist.Where(i => i.title.ToLower().Contains(uidName.ToLower())).ToList();

            if (rdf != null)
            {
                foreach (rdfObject obj in result)
                {
                    if (!string.IsNullOrEmpty(obj.identifier) && obj.parentUid.Equals(parentID))
                    {
                        rdf = obj;
                    }
                }
            }
            return rdf;
        }
            
        

        private rdfObject selectNode(XElement temp)
        {
            string pkID = null;
            rdfObject rdf = new rdfObject();
            XElement firstNode = (XElement)temp.FirstNode;
            XNamespace getNamespaceOfPrefix = firstNode.GetNamespaceOfPrefix("dcterms");
            XNamespace getNamespaceOfPrefixss = firstNode.GetNamespaceOfPrefix("ss");
            rdf.title = firstNode.Descendants(getNamespaceOfPrefix + "title").FirstOrDefault().Value;
            var result = (from temp1 in temp.Descendants(getNamespaceOfPrefix + "description")
                          select temp).ToList();
            if (result.Count>0)
            {
                rdf.description = firstNode.Descendants(getNamespaceOfPrefix + "description").FirstOrDefault().Value;
            }
            rdf.type = firstNode.Descendants(getNamespaceOfPrefix + "type").FirstOrDefault().Value;
            rdf.identifier = firstNode.Descendants(getNamespaceOfPrefix + "identifier").FirstOrDefault().Value;
            rdf.parentUid= firstNode.Descendants(getNamespaceOfPrefixss + "parentresourceidentifier").FirstOrDefault().Value;
            firstNode.Descendants(getNamespaceOfPrefix + "type");
            //ParentUID = ParentUID.Replace(" ", string.Empty);
            
            return rdf;
        }

/*        private ProcessStatusCode DeletePackage(string project, string pkID)
        {
            ProcessStatusCode result = ProcessStatusCode.Successful;
            EAClient Eaclient = this.eaClient;
            string url = "/oslc/am/resource/";
            string responseXML = null;
            string conString = project + url + pkID + "/";
            using (HttpWebResponse response = Eaclient.DeletePackageById(conString, "DELETE", true))
            {
                responseXML = GetResponseXmlString(response);
                //getResponse = Eaclient.GetPackageFromPackageRef(project, uid, objectType);
            }

            return result;
        }*/
        private ProcessStatusCode CreateResource(string project, string objectType, string uid,string stereoType, ref string parentID, out string responseXML)
        {
                     
            ProcessStatusCode result = ProcessStatusCode.Successful;
            EAClient Eaclient = this.eaClient;
            string url = "/oslc/am/cf/resource/";
            string conString = project + url;
            StringBuilder sb = new StringBuilder();
            XmlWriterSettings xws = new XmlWriterSettings();
            xws.OmitXmlDeclaration = true;
            xws.Indent = true;
            XDocument doc = null;

            using (XmlWriter xw = XmlWriter.Create(sb, xws))
            {
                XNamespace ns1 = "http://open-services.net/ns/am#";
                XNamespace ns2 = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
                XNamespace ns3 = "http://purl.org/dc/terms/";
                XNamespace ns4 = "http://xmlns.com/foaf/0.1/";
                XNamespace ns5 = "http://www.sparxsystems.com.au/oslc_am#";
                doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"));
                XElement reportElement = new XElement(ns2 + "RDF",
                    new XAttribute(XNamespace.Xmlns + "oslc_am", ns1),
                    new XAttribute(XNamespace.Xmlns + "rdf", ns2),
                    new XAttribute(XNamespace.Xmlns + "dcterms", ns3),
                    new XAttribute(XNamespace.Xmlns + "foaf", ns4),
                    new XAttribute(XNamespace.Xmlns + "ss", ns5));
                doc.Add(reportElement);
                reportElement.Add(new XElement(ns1 + "Resource",
                        new XElement(ns3 + "title", uid), new XElement(ns3 + "type", objectType), new XElement(ns5 + "resourcetype", "Package"), new XElement(ns5 + "parentresourceidentifier", parentID), new XElement(ns5 + "stereotype", new XElement(ns5 + "stereotypename", new XElement(ns5 + "name", stereoType)))));
                doc.WriteTo(xw);
            }

            //System.Diagnostics.Debug.Write(sb.ToString());
            using (HttpWebResponse response = Eaclient.CreateResources(conString, doc.ToString(), "POST", true))
            {
                responseXML = GetResponseXmlString(response);
                this.LogAndEmail(string.Format("EA Plugin, Resources created  successfully", responseXML));
                parentID = null;
                return result;
            }
        }

        private ProcessStatusCode GetNestedresourcesByParentid(string project, string objectType, ref string rootId, out string responseXML)
        {
            ProcessStatusCode result = ProcessStatusCode.Successful;
            EAClient eAClient = this.eaClient;
            string url = "/oslc/am/nestedresources/";
            string conString = project + url + rootId + "/";
            try
            {
                using (HttpWebResponse response = eAClient.GetNestedResources(conString, string.Empty, "GET", true, null))
                {
                    responseXML = GetResponseXmlString(response);
                    return result;
                }
            }
            catch (Exception ex)
            {
                this.LogAndEmail(string.Format("EA Plugin, server returned invalid response xml\r\nError:{0}", ex.Message));
                result= ProcessStatusCode.HadUnrecoverableErrors;
                responseXML = null;
                return result;
            }
        }

        private ProcessStatusCode GetParentId(string project, string objectType, string rootName, out string parentID, out string XDocumentRes)
        {
            ProcessStatusCode result = ProcessStatusCode.Successful;
            string responseXML = null;
            EAClient eAClient = this.eaClient;
            string url = "/oslc/am/qc/?oslc.select=* & oslc.where=dcterms:title=";
            string conString = project + url + '"' + rootName + '"';
            using (HttpWebResponse response = eAClient.GetRoot(conString, string.Empty, "GET", true))
            {
                XDocument doc = null;
                responseXML = GetResponseXmlString(response);
                try
                {
                    doc = XDocument.Parse(responseXML);
                    XDocumentRes = responseXML;
                }
                catch (Exception)
                {
                    this.LogAndEmail(string.Format("EA Plugin, server returned invalid response xml\r\nError:{0}", responseXML));
                    parentID = null;
                    XDocumentRes = null;
                    return ProcessStatusCode.HadUnrecoverableErrors;
                }
                string id = null;
                XElement node = (XElement)doc.FirstNode;
                XNamespace name = node.GetNamespaceOfPrefix("rdfs");
                IEnumerable<XElement> member = node.Descendants(name + "member");
                foreach (XElement temp in member)
                {

                    rdfObject rdf = selectNode(temp);
                    if (rdf.title.ToLower() == (rootName.ToLower()))
                    {
                        id = rdf.identifier;

                    }
                    if (id!=null)
                    {
                        break;
                    }
                }
                parentID = id;
                this.LogAndEmail(string.Format("Get Parent  Id by RootName {0} :", parentID));
                return result;
            }
        }


        private ProcessStatusCode ApplyParentTypeMapping(string parentTypeMappingKey, ref string parentType)
        {
            if (!string.IsNullOrEmpty(parentTypeMappingKey))
            {
                if (this.dataMappingLookup.ContainsKey(parentTypeMappingKey))
                {
                    if (this.dataMappingLookup[parentTypeMappingKey].ContainsKey(parentType))
                    {
                        parentType = this.dataMappingLookup[parentTypeMappingKey][parentType];
                        return ProcessStatusCode.Successful;
                    }
                    else
                    {
                        this.LogAndEmail(string.Format("EA Plugin, warning: parent type mapping {0} has no mapping for {1}, assuming direct map", parentTypeMappingKey, parentType));
                        return ProcessStatusCode.IssuedWarnings;
                    }
                }
                else
                {
                    this.LogAndEmail(string.Format("EA Plugin, error: failed trying to load mapping {0}", parentTypeMappingKey));
                    return ProcessStatusCode.HadUnrecoverableErrors;
                }
            }
            //No mapping key
            return ProcessStatusCode.Successful;

        }

        public void Terminate()
        {

        }
        public ProcessStatusCode CustomCommand(string directive)
        {
            throw new NotImplementedException();
        }


        private static string GetResponseXmlString(HttpWebResponse response)
        {

            string retval = string.Empty;
            if (response != null)
            {
                using (StreamReader responseReader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8))
                {
                    retval = responseReader.ReadToEnd();
                }
            }

            return retval;
        }
    }
}
#endregion

