﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public  class EnergyGeneratedData
    {
        public Decimal Value { get; set; }
        public DateTime timestamp { get; set; }

    }
    public partial class EnergyDataResponse
    {
        public Double totalInstalledCapacity { get; set; }
        public String billExpectedDate { get; set; }
        public  List<EnergyGeneratedData> data { get; set; }
       
    }
}
