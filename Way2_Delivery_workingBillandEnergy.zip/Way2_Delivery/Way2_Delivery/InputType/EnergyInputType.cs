﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class EnergyInputType : ObjectGraphType<EnergyDataResponse>
    {
        public EnergyInputType()
        {

            Field(x => x.totalInstalledCapacity, type: typeof(StringGraphType)).Description("Value Credits data.");
            Field(x => x.billExpectedDate, type: typeof(StringGraphType)).Description("Value Credits data.");
            Field(x => x.data, nullable: true, type: typeof(ListGraphType<EnergyGeneratedData1>)).Description("List");
        }
    }
}