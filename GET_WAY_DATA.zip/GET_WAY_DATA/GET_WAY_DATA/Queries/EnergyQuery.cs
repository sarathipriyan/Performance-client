﻿using GET_WAY_DATA.GraphQL.GraphTypes;
using GET_WAY_DATA.Models;
using GET_WAY_DATA.Repositories.Interfaces;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GET_WAY_DATA.Queries
{
    public class EnergyQuery : ObjectGraphType
    {
        private readonly IEnergyRepository _customerRepository;

        public EnergyQuery(IEnergyRepository customerRepository)
        {
            _customerRepository = customerRepository;

            Field<ListGraphType<EnergyType>>("PowerSupplys", resolve: context => _customerRepository.GetAll());
            Field<EnergyType>("PowerSupply", arguments: new QueryArguments(new
                                    QueryArgument<IntGraphType>
            { Name = "id" }),
                                resolve:
                                context => _customerRepository.GetCustomerById(context.GetArgument<int>("id")));

        }

    }
}
