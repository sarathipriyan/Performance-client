﻿using GET_WAY_DATA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GET_WAY_DATA.Repositories.Interfaces
{
    public interface IEnergyRepository
    {
        List<Energy> GetAll();
        Energy GetCustomerById(long id);
    }
}
