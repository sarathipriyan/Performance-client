﻿using GET_WAY_DATA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GET_WAY_DATA.Repositories.Interfaces
{
    public class EnergyRepository : IEnergyRepository
    {
        private readonly DEMO_DB_WAY2Context _context;
        public EnergyRepository(DEMO_DB_WAY2Context context)
        {
            _context = context;
        }

        public List<Energy> GetAll()
        {
            return _context.Energy.ToList();
        }

        public Energy GetCustomerById(long id) => _context.Energy.FirstOrDefault(c => c.Id == id);
    }
}
