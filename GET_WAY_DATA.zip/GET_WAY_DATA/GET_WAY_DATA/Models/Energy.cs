﻿using System;
using System.Collections.Generic;

namespace GET_WAY_DATA.Models
{
    public partial class Energy
    {
        public long Id { get; set; }
        public long IdEnergy { get; set; }
        public long IdPlant { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal GeneratedCredits { get; set; }
        public decimal Consumption { get; set; }
        public decimal Balance { get; set; }
        public decimal Credits { get; set; }
        public decimal CumulativeBalance { get; set; }
        public long NumberofUcs { get; set; }
        public DateTime DailyDate { get; set; }
        public string PowerSupplyname { get; set; }
    }
}
