﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GET_WAY_DATA.Models
{
    public partial class DEMO_DB_WAY2Context : DbContext
    {
        public DEMO_DB_WAY2Context()
        {
        }

        public DEMO_DB_WAY2Context(DbContextOptions<DEMO_DB_WAY2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Energy> Energy { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=DEMO_DB_WAY2;Trusted_Connection=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Energy>(entity =>
            {
                entity.ToTable("ENERGY");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Balance).HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Consumption).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.Credits).HasColumnType("numeric(19, 0)");

                entity.Property(e => e.CumulativeBalance).HasColumnType("numeric(19, 0)");

                entity.Property(e => e.DailyDate).HasColumnType("date");

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.GeneratedCredits).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.PowerSupplyname)
                    .HasColumnName("powerSupplyname")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate)
                    .HasColumnName("startDate")
                    .HasColumnType("date");
            });
        }
    }
}
