﻿using GET_WAY_DATA.Queries;
using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GET_WAY_DATA.Schemas
{
    public class EnergySchema : Schema
    {
        public EnergySchema(IDependencyResolver resolver) : base(resolver)
        {
            Query = resolver.Resolve<EnergyQuery>();

        }
    }
}
