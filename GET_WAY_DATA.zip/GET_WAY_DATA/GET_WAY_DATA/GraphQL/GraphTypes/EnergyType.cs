﻿using GET_WAY_DATA.Models;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GET_WAY_DATA.GraphQL.GraphTypes
{
    public class EnergyType : ObjectGraphType<Energy>
    {
        public EnergyType()
        {
            Field(PowerSupplyID => PowerSupplyID.Id);
            Field(PowerSupplyID => PowerSupplyID.IdEnergy);
            Field(PowerSupplyID => PowerSupplyID.PowerSupplyname);
            Field(PowerSupplyID => PowerSupplyID.GeneratedCredits);
            Field(PowerSupplyID => PowerSupplyID.CumulativeBalance);
            Field(PowerSupplyID => PowerSupplyID.IdPlant);
            Field(PowerSupplyID => PowerSupplyID.StartDate);
            Field(PowerSupplyID => PowerSupplyID.EndDate);
            Field(PowerSupplyID => PowerSupplyID.Credits);
            Field(PowerSupplyID => PowerSupplyID.DailyDate);
            Field(PowerSupplyID => PowerSupplyID.NumberofUcs);
            Field(PowerSupplyID => PowerSupplyID.Consumption);
            Field(PowerSupplyID => PowerSupplyID.Balance);

        }
    }
}
