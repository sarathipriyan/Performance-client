﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using Way2_Delivery.Repo;
using Way2_Delivery.InputType;
using Way2_Delivery.Models;

namespace Way2_Delivery
{
    public class GeneralQuery : ObjectGraphType
    {
        public class IntervalGraphType: EnumerationGraphType<Interval>
        {
        }

        public GeneralQuery(IGeneralRepository repository)
        {
            Field<ListGraphType<EnergyInputType>>("EnergyQuery",
            arguments: new QueryArguments(
            new QueryArgument<ListGraphType<NonNullGraphType<StringGraphType>>> { Name = "supplyIds" },
            new QueryArgument<StringGraphType> { Name = "startDate" },
            new QueryArgument<StringGraphType> { Name = "endDate" },
            new QueryArgument<IntervalGraphType> { Name = "interval" }
            ), resolve: context =>
    {
            List<String> idList = context.GetArgument<List<String>>("supplyIds");
            String startDate = context.GetArgument<String>("startDate");
            String endDate = context.GetArgument<String>("endDate");
            Interval interval = context.GetArgument<Interval>("interval");

            return repository.GetEnergyDataByFilters(idList, startDate, endDate,interval);
            });

            Field<ListGraphType<BillInputType>>("BillingQuery",
           arguments: new QueryArguments(
           new QueryArgument<ListGraphType<NonNullGraphType<StringGraphType>>> { Name = "supplyIds" },
           new QueryArgument<StringGraphType> { Name = "startDate" },
           new QueryArgument<StringGraphType> { Name = "endDate" }
           ), resolve: context =>
           {
               List<String> idList = context.GetArgument<List<String>>("supplyIds");
               String startDate = context.GetArgument<String>("startDate");
               String endDate = context.GetArgument<String>("endDate");
               return repository.GetBillStatusByFilters(idList, startDate, endDate);
           });
        }
    }
}
