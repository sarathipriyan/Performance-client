﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class EnergyInputType : ObjectGraphType<EnergyDataResponse>
    {
        public EnergyInputType()
        {
          
            Field(x => x.billExpectedDate, type: typeof(StringGraphType)).Description("Id of the power distributor");
            Field(x => x.totalInstalledCapacity, type: typeof(StringGraphType)).Description("Name of the power distributor.");
            Field(x => x.data, type: typeof(ListGraphType)).Description("Generated Credits data.");
        }
    }
}