﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class BillInputType : ObjectGraphType<BillResponse>
    {
        public class BillTypeGraphType : EnumerationGraphType<BillType>
        {
        }


        public BillInputType()
        {
            Field(x => x.powerSupplyId, type: typeof(StringGraphType)).Description("Id of the power distributor for this bill");
            Field(x => x.powerSupplyName, type: typeof(StringGraphType)).Description("Name of the power distributor for this bill");
            Field(x => x.processed, type: typeof(DecimalGraphType)).Description("% of successfully processed bill ");
            Field(x => x.notProcessed, type: typeof(DecimalGraphType)).Description("% of late  NonProcessed bill");
            Field(x => x.late, type: typeof(DecimalGraphType)).Description("% of late late bill");
            Field(x => x.type, type: typeof(BillTypeGraphType)).Description("type indicating whether its genertion or consumption (GENERATION/CONSUMPTION)");
            Field(x => x.date, type: typeof(StringGraphType)).Description("Billing Date");
        }
    }
}