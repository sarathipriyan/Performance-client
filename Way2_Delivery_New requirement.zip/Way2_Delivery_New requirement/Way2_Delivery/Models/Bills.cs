﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public enum BillType
    {
        Generated = 1,
        Consumption = 2
    }
    public partial class Bills
    {
        public int Id { get; set; }
        public int IdConsumer { get; set; }
        public int Source { get; set; }
        public int TariffType { get; set; }
        public DateTime ReferenecDate { get; set; }
        public decimal TotalExpectedTaxes { get; set; }
        public decimal Taxes { get; set; }
        public decimal TotalAmount { get; set; }
        public short NumberofFiles { get; set; }
        public bool TariffIncludesTaxes { get; set; }
        public bool Validated { get; set; }
        public string Annotations { get; set; }
        public int Alerts { get; set; }
        public DateTime InsertedAt { get; set; }
        public long DateTime { get; set; }
        public decimal CumulativeGeneration { get; set; }
        public int BillCalculationTrigger { get; set; }
        public short BillStatus { get; set; }
        public int Type { get; set; }

        public virtual Consumerdata IdConsumerNavigation { get; set; }
    }
}
