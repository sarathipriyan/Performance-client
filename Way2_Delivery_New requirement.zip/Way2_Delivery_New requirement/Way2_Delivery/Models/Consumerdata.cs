﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Consumerdata
    {
        public Consumerdata()
        {
            Bills = new HashSet<Bills>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string IdPlant { get; set; }
        public long Code { get; set; }
        public string GroupType { get; set; }
        public string ClientId { get; set; }
        public string TaxModality { get; set; }
        public string BillUser { get; set; }
        public string BillPassword { get; set; }

        public virtual Plantdata IdPlantNavigation { get; set; }
        public virtual ICollection<Bills> Bills { get; set; }
    }
}
