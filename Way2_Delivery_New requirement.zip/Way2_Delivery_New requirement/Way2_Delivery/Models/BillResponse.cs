﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class BillResponse
    {
        public String powerSupplyId { get; set; }
        public String powerSupplyName { get; set; }
        public Double processed { get; set; }
        public Double notProcessed { get; set; }
        public Double late { get; set; }
        public BillType type { get; set; }
        public DateTime date { get; set; }
        public decimal CumulativeGeneration { get; set; }
    }

    public partial class BillDataResponse
    {
        public String powerSupplyId { get; set; }
        public String powerSupplyName { get; set; }
        public decimal CumulativeGeneration { get; set; }
    }
}
