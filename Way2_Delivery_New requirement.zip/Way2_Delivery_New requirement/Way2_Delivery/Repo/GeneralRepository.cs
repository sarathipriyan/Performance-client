﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.Repo
{
    public class GeneralRepository : IGeneralRepository
    {
        public readonly DB_TEST_VERSION2_NEWContext _context;
        public GeneralRepository(DB_TEST_VERSION2_NEWContext context)
        {
            _context = context;
        }
        public List<EnergyDataResponse> GetEnergyDataByFilters(List<string> powerSupplyIds, string startDate, string endDate, Interval interval)
        {
            //calculate total installed capacity of all plants
            long allPlantsCapacity = 0;
            String plantName = String.Empty;

            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Energy> energyData = getEnergyDataByPowerSupplyIds(powerSupplyIds);
            if(energyData.Count > 0 )
            {
                energyData = energyData.Where(energy => energy.DateTime >= startTime).ToList();
                energyData = energyData.Where(energy => energy.DateTime <= endTime).ToList();

            }
            if(interval.Equals(Interval.Daily))
            {
                Dictionary<string, Energy> aggEnergyPerDay = new Dictionary<string, Energy>();
                for (int i=0; i < energyData.Count; i ++ )
                {
                    DateTime energyTime = Epoch2UTCNow(energyData[i].DateTime);
                    String Date = energyTime.ToString("yyyy-MM-dd");

                    aggregateEnergyData(aggEnergyPerDay, energyData[i],Date);
                    
                }
                energyData = aggEnergyPerDay.Select(x => x.Value).ToList();

                for(int i=0; i<powerSupplyIds.Count; i++)
                {

                    List<Plantdata> plants = _context.Plantdata.ToList().Where(plant => plant.Id == powerSupplyIds[i]).ToList();
                    if (plants.Count == 1)
                    {
                        Plantdata plant = plants[0];
                        allPlantsCapacity += plant.InstalledCapacity;
                        //get the first plant name
                        if (i == 0)
                        {
                            plantName = plant.Name;
                        }

                    }
                    else if(plants.Count == 0) 
                    {
                        //log a error sayingno plant exist with this plantId
                    } else
                    {
                        //log a error about more than one plant forsamme id
                    }

                }

            }
        

            List<EnergyDataResponse> energyResp = convertEnergyDataToResponse(energyData, powerSupplyIds, allPlantsCapacity, plantName);
            return energyResp;
        }

        private void aggregateEnergyData(Dictionary<string, Energy> aggEnergy, Energy currEnergy, String date)
        {
            //get the epoch time for the date with midnight time ie YYYY-MM_DDT00:00:00
            DateTime dt = DateTime.ParseExact(date, "yyyy-MM-dd", null);
            long epoch = DateTimeToEpoch(dt);

            if (aggEnergy.ContainsKey(date))
            {
                Energy newData = aggregateData(currEnergy, aggEnergy.GetValueOrDefault(date));
                newData.DateTime = epoch;
                aggEnergy[date] = newData;
            } else
            {
                currEnergy.DateTime = epoch;
                aggEnergy.Add(date, currEnergy);
            }
            
        }

        private Energy aggregateData(Energy currEnergy, Energy energy)
        {
            currEnergy.Value += energy.Value;
            return currEnergy;
        }

        private DateTime Epoch2UTCNow(long epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(epoch);
        }

        private long DateTimeToEpoch(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan diff = date.ToUniversalTime() - origin;
            return Convert.ToInt64(diff.TotalSeconds);
        }
        private List<Energy> getEnergyDataByPowerSupplyIds(List<String> ids)
        {
            List<Energy> energyData = new List<Energy>();
            List<Energy> Energy = _context.Energy.ToList();
            energyData = Energy.Where(energy => ids.Contains(energy.IdPlant.ToString())).ToList();
            return energyData;
        }

        public List<EnergyDataResponse> convertEnergyDataToResponse(List<Energy> energyDataList, List<string> powerSupplyIds, long totalCapacity, String plantName)
        {
            List<EnergyDataResponse> respData = new List<EnergyDataResponse>();
            
                EnergyDataResponse tmpData = new EnergyDataResponse();

            foreach (var energyData in energyDataList) {
                EnergyGeneratedData data = new EnergyGeneratedData();
                data.Value = energyData.Value;
                data.timestamp = Epoch2UTCNow(energyData.DateTime);

           }
                if (powerSupplyIds.Count == 1)
                {
                //get powerbillexpecteddate from plantdata table for this plantid
                 //   tmpData.billExpectedDate = energyData[i].IdPlantNavigation.PowerBillExpectedDate.ToString();
                }
            tmpData.totalInstalledCapacity = totalCapacity;
                respData.Add(tmpData);
            

            return respData;
        }

        public String getPowerSupplyNameFromId(string id)
        {

            List<Plantdata> plantidlist = _context.Plantdata.ToList().Where(energy => energy.Id == id).ToList();
            //List<int> plantid = plantidlist.ToList().Select(x => x.IdPowerDistributor).ToList();
           // List<Powerdistributor> pds = _context.Powerdistributor.ToList().Where(powedistributor => plantid.Contains(powedistributor.Id)).ToList();
            String PlantName = "";
            if (plantidlist.Count == 1)
            {
                PlantName = plantidlist[0].Name;
            }
            return PlantName;
        }
        public String getPowersupplyNameFromID(int id)
        {
            String powerSupplyName = "";
            List<Powerdistributor> pds = _context.Powerdistributor.ToList().Where(distributor => distributor.Id == id).ToList();
            if (pds.Count == 1)
            {
                powerSupplyName = pds[0].PowerSupplyName;
            }
            return powerSupplyName;
        }
        public List<BillResponse> GetBillStatusByFilters(List<string> powerSupplyIds, string startDate, string endDate)
        {
            List<BillResponse> billData = new List<BillResponse>();
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> BillData = getBillDataByPowerSupplyIds(powerSupplyIds);
            if (BillData.Count > 0)
            {
                BillData = BillData.Where(bill => bill.DateTime >= startTime).ToList();
                BillData = BillData.Where(bill => bill.DateTime <= endTime).ToList();

            }

            List<Bills> generatedBillData = BillData.Where(bill => bill.Type == (int)BillType.Generated).ToList();
            List<Bills> consumerBillData = BillData.Where(bill => bill.Type == (int)BillType.Consumption).ToList();
            List<BillResponse> billResp = convertBillDataToResponse(generatedBillData);
            billResp.AddRange(convertBillDataToResponse(consumerBillData));
            return billResp;
        }

        public List<BillResponse> convertBillDataToResponse(List<Bills> billdata)
        {
            List<BillResponse> respData = new List<BillResponse>();

            List<string> powerSupplyIds = billdata.Select(x => x.IdConsumerNavigation.IdPlant.ToString()).ToList();

            for (int i = 0; i < powerSupplyIds.Count; i++)
            {
                BillResponse tmpData = new BillResponse();
                Plantdata plant = _context.Plantdata.ToList().Where(x => x.Id == powerSupplyIds[i]).ToList()[0];
                tmpData.powerSupplyId = powerSupplyIds[i].ToString();
                tmpData.powerSupplyName = getPowersupplyNameFromID(billdata[i].IdConsumerNavigation.IdPlantNavigation.IdPowerDistributor); ;

                int processedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlant == powerSupplyIds[i].ToString()).ToList()
                                        .Count(x => x.BillStatus == 1);
                int nonProcessedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlant == powerSupplyIds[i].ToString()).ToList()
                                        .Count(x => x.BillStatus == 2);
                int lateProcessedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlant == powerSupplyIds[i].ToString()).ToList()
                                        .Count(x => x.BillStatus == 3);

                tmpData.processed = (processedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.notProcessed = (nonProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.late = (lateProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.date = plant.PowerBillExpectedDate;

                if(billdata[i].Type == (int)BillType.Generated)
                {
                    tmpData.type = BillType.Generated;
                } 
                else
                {
                    tmpData.type = BillType.Consumption;
                }
                
                respData.Add(tmpData);
            }
            
            return respData;
        }

       

        private List<Bills> getBillDataByPowerSupplyIds(List<String> ids)
        {
            List<Bills> BillData = new List<Bills>();
            List<Consumerdata> ConsumerData = new List<Consumerdata>();
           
               ConsumerData = _context.Consumerdata.ToList().Where(consumer => ids.Contains(consumer.IdPlant.ToString())).ToList();
               List<int> Consumerids= ConsumerData.ToList().Select(x => x.Id).ToList();
               BillData = _context.Bills.ToList();
               BillData = BillData.Where(bill => Consumerids.Contains(bill.IdConsumer)).ToList();

            
            return BillData;
        }
        public List<BillDataResponse> GetBillDataByFilters(List<string> powerSupplyIds, string startDate, string endDate)
        {
            List<BillResponse> billData = new List<BillResponse>();
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> BillData = getBillDataByIds(powerSupplyIds);
            if (BillData.Count > 0)
            {
                BillData = BillData.Where(bill => bill.DateTime >= startTime).ToList();
                BillData = BillData.Where(bill => bill.DateTime <= endTime).ToList();

            }

            
            List<BillDataResponse> billResp = convertSumofBillDataToResponse(powerSupplyIds, BillData);
            
            return billResp;
        }
        private List<Bills> getBillDataByIds(List<String> ids)
        {
            List<Bills> BillData = new List<Bills>();
            List<Consumerdata> ConsumerData = new List<Consumerdata>();

            ConsumerData = _context.Consumerdata.ToList().Where(consumer => ids.Contains(consumer.IdPlant.ToString())).ToList();
            List<int> Consumerids = ConsumerData.ToList().Select(x => x.Id).ToList();
            BillData = _context.Bills.ToList();
            BillData = BillData.Where(bill => Consumerids.Contains(bill.IdConsumer)).ToList();


            return BillData;
        }
        public List<BillDataResponse> convertSumofBillDataToResponse(List<string> powerSupplyIds, List<Bills> billdata)
        {
            List<BillDataResponse> respData = new List<BillDataResponse>();
            BillDataResponse tmpData = new BillDataResponse();
            for (int i = 0; i < billdata.Count; i++)
             {

                tmpData.CumulativeGeneration += billdata[i].CumulativeGeneration;
            }
            
            if (powerSupplyIds.Count == 1)
            {
                String plantId = powerSupplyIds[0];
                List<Plantdata> plantList = _context.Plantdata.ToList().Where(plant => plant.Id == plantId).ToList();
                if(plantList.Count == 1)
                {
                    tmpData.powerSupplyId = plantId;
                    tmpData.powerSupplyName = plantList[0].Name;
                }

            }
            respData.Add(tmpData);
            return respData;
        }


    }
}
