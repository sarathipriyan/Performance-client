﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Way2_Delivery.Models
{
    public partial class DB_TEST_VERSION2_NEWContext : DbContext
    {
        public DB_TEST_VERSION2_NEWContext()
        {
        }

        public DB_TEST_VERSION2_NEWContext(DbContextOptions<DB_TEST_VERSION2_NEWContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Bills> Bills { get; set; }
        public virtual DbSet<Consumerdata> Consumerdata { get; set; }
        public virtual DbSet<Energy> Energy { get; set; }
        public virtual DbSet<Plantdata> Plantdata { get; set; }
        public virtual DbSet<Powerdistributor> Powerdistributor { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=DB_TEST_VERSION2_NEW;Trusted_Connection=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Bills>(entity =>
            {
                entity.ToTable("BILLS");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Annotations).HasMaxLength(4000);

                entity.Property(e => e.CumulativeGeneration).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.InsertedAt).HasColumnType("datetime");

                entity.Property(e => e.ReferenecDate).HasColumnType("datetime");

                entity.Property(e => e.Taxes).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.TotalAmount).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.TotalExpectedTaxes).HasColumnType("numeric(19, 5)");

                entity.Property(e => e.Type).HasColumnName("type");

                entity.HasOne(d => d.IdConsumerNavigation)
                    .WithMany(p => p.Bills)
                    .HasForeignKey(d => d.IdConsumer)
                    .HasConstraintName("FK__BILLS__IdConsume__2F10007B");
            });

            modelBuilder.Entity<Consumerdata>(entity =>
            {
                entity.ToTable("CONSUMERDATA");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.BillPassword)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillUser)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GroupType)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IdPlant)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TaxModality)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdPlantNavigation)
                    .WithMany(p => p.Consumerdata)
                    .HasForeignKey(d => d.IdPlant)
                    .HasConstraintName("FK__CONSUMERD__IdPla__2C3393D0");
            });

            modelBuilder.Entity<Energy>(entity =>
            {
                entity.ToTable("ENERGY");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.IdPlant)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsertedAt).HasColumnType("datetime");

                entity.Property(e => e.Value).HasColumnType("numeric(19, 5)");

                entity.HasOne(d => d.IdPlantNavigation)
                    .WithMany(p => p.Energy)
                    .HasForeignKey(d => d.IdPlant)
                    .HasConstraintName("FK__ENERGY__IdPlant__29572725");
            });

            modelBuilder.Entity<Plantdata>(entity =>
            {
                entity.ToTable("PLANTDATA");

                entity.HasIndex(e => e.IdPowerDistributor)
                    .HasName("UQ__PLANTDAT__1CA54742999F077F")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.MeasuringPoint)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PowerBillExpectedDate).HasColumnType("date");

                entity.Property(e => e.Source)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TypeofDistributedEnergy)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdPowerDistributorNavigation)
                    .WithOne(p => p.Plantdata)
                    .HasForeignKey<Plantdata>(d => d.IdPowerDistributor)
                    .HasConstraintName("FK__PLANTDATA__IdPow__267ABA7A");
            });

            modelBuilder.Entity<Powerdistributor>(entity =>
            {
                entity.ToTable("POWERDISTRIBUTOR");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.PowerSupplyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });
        }
    }
}
