﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class Energy
    {
        public int Id { get; set; }
        public int IdPlant { get; set; }
        public DateTime InsertedAt { get; set; }
        public long DateTime { get; set; }
        public decimal Value { get; set; }
        public int ToU { get; set; }
        public int Quality { get; set; }
        public double GeneratedCredits { get; set; }
        public double Consumption { get; set; }
        public double Balance { get; set; }
        public double Credits { get; set; }
        public double CumulativeBalance { get; set; }
        public int NumberofUcs { get; set; }

        public virtual Plantdata IdPlantNavigation { get; set; }
    }
}
