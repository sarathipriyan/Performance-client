﻿using System;
using System.Collections.Generic;

namespace Way2_Delivery.Models
{
    public partial class EnergyDataResponse
    {
        public String powerSupplyId { get; set; }
        public String powerSupplyName { get; set; }
        public Double generatedCredits { get; set; }
        public Double consumption { get; set; }
        public Double balance { get; set; }
        public Double credits { get; set; }
        public Double cumulativeBalance { get; set; }

        public int numberOfUcs { get; set; }
        public DateTime timestamp { get; set; }
    }
}
