﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.Repo
{
    public interface IGeneralRepository
    {
        List<EnergyDataResponse> GetEnergyByFilters(List<string> idList, string startDate, string endDate, string interval);
        List<BillResponse> GetBillByFilters(List<string> idList, string startDate, string endDate);
    }

}
