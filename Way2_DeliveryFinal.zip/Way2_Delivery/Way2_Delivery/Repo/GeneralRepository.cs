﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.Repo
{
    public class GeneralRepository : IGeneralRepository
    {
        public readonly WAY2TESTDEMOContext _context;
        public GeneralRepository(WAY2TESTDEMOContext context)
        {
            _context = context;
        }
        public List<EnergyDataResponse> GetEnergyByFilters(List<string> powerSupplyIds, string startDate, string endDate, string interval)
        {
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Energy> energyData = getEnergyDataByPowerSupplyIds(powerSupplyIds);
            if(energyData.Count > 0 )
            {
                energyData = energyData.Where(energy => energy.DateTime >= startTime).ToList();
                energyData = energyData.Where(energy => energy.DateTime <= endTime).ToList();

            }
            if(interval.Equals("Daily"))
            {
                for (int i=0; i < energyData.Count; i ++ )
                {

                }
            }

            List<EnergyDataResponse> energyResp = convertEnergyDataToResponse(energyData);
            return energyResp;
        }
        private List<Energy> getEnergyDataByPowerSupplyIds(List<String> ids)
        {
            List<Energy> energyData = new List<Energy>();
            List<Plantdata> plants = _context.Plantdata.ToList();
            plants = plants.Where(plant => ids.Contains(plant.IdPowerDistributor.ToString())).ToList();
            if (plants.Count > 0)
            {
                List<int> plantIds = plants.Select(x => x.Id).ToList();
                energyData = _context.Energy.ToList();
                energyData = energyData.Where(energy => plantIds.Contains(energy.IdPlant)).ToList();
            }
            return energyData;
        }

        public List<EnergyDataResponse> convertEnergyDataToResponse(List<Energy> energyData)
        {
            List<EnergyDataResponse> respData = new List<EnergyDataResponse>();

            for (int i=0; i < energyData.Count; i ++ )
            {
                EnergyDataResponse tmpData = new EnergyDataResponse();

                tmpData.powerSupplyId = energyData[i].IdPlantNavigation.IdPowerDistributor.ToString();

                tmpData.powerSupplyName = getPowerSupplyNameFromId(energyData[i].IdPlantNavigation.IdPowerDistributor);
                tmpData.balance = energyData[i].Balance;
                tmpData.consumption = energyData[i].Consumption;
                tmpData.credits = energyData[i].Credits;
                tmpData.cumulativeBalance = energyData[i].CumulativeBalance;
                tmpData.numberOfUcs = energyData[i].NumberofUcs;
                tmpData.generatedCredits = energyData[i].GeneratedCredits;
                tmpData.timestamp = energyData[i].InsertedAt;

                respData.Add(tmpData);
            }

            return respData;
        }
       
        public String getPowerSupplyNameFromId(int id)
        {
            String powerSupplyName = "";
            List<Powerdistributor> pds =  _context.Powerdistributor.ToList().Where(distributor => distributor.Id == id).ToList();
            if (pds.Count == 1)
            {
                powerSupplyName = pds[0].PowerSupplyName;
            }
            return powerSupplyName;
        }

        public List<BillResponse> GetBillByFilters(List<string> powerSupplyIds, string startDate, string endDate)
        {
            List<BillResponse> billData = new List<BillResponse>();
            long startTime = DateTimeOffset.Parse(startDate).ToUnixTimeSeconds();
            long endTime = DateTimeOffset.Parse(endDate).ToUnixTimeSeconds();
            List<Bills> BillData = getBillDataByPowerSupplyIds(powerSupplyIds);
            if (BillData.Count > 0)
            {
                BillData = BillData.Where(bill => bill.DateTime >= startTime).ToList();
                BillData = BillData.Where(bill => bill.DateTime <= endTime).ToList();

            }
            

            List<BillResponse> billResp = convertBillDataToResponse(BillData);
            return billResp;
        }

        public List<BillResponse> convertBillDataToResponse(List<Bills> billdata)
        {
            List<BillResponse> respData = new List<BillResponse>();

            List<int> powerSupplyIds = billdata.Select(x => x.IdConsumerNavigation.IdPlantNavigation.IdPowerDistributor).ToList();

            for (int i = 0; i < powerSupplyIds.Count; i++)
            {
                BillResponse tmpData = new BillResponse();
                Plantdata plant = _context.Plantdata.ToList().Where(x => x.IdPowerDistributor == powerSupplyIds[i]).ToList()[0];
                tmpData.powerSupplyId = powerSupplyIds[i].ToString();
                tmpData.powerSupplyName = "toBeFilled";

                int processedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlantNavigation.IdPowerDistributor == powerSupplyIds[i]).ToList()
                                        .Count(x => x.BillStatus == 1);
                int nonProcessedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlantNavigation.IdPowerDistributor == powerSupplyIds[i]).ToList()
                                        .Count(x => x.BillStatus == 2);
                int lateProcessedBillCnt = billdata.Where(data => data.IdConsumerNavigation.IdPlantNavigation.IdPowerDistributor == powerSupplyIds[i]).ToList()
                                        .Count(x => x.BillStatus == 3);

                tmpData.processed = (processedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.notProcessed = (nonProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.late = (lateProcessedBillCnt * 100) / (processedBillCnt + nonProcessedBillCnt + lateProcessedBillCnt);
                tmpData.date = plant.PowerBillExpectedDate;
                tmpData.type = plant.TypeofDistributedEnergy;

                respData.Add(tmpData);
            }

            return respData;
        }

       

        private List<Bills> getBillDataByPowerSupplyIds(List<String> ids)
        {
            List<Bills> BillData = new List<Bills>();
            List<Consumerdata> ConsumerData = new List<Consumerdata>();
            List<Plantdata> plants = _context.Plantdata.ToList().Where(plant => ids.Contains(plant.IdPowerDistributor.ToString())).ToList();
            if (plants.Count > 0)
            {
               List<int> plantIds = plants.Select(x => x.Id).ToList();
               ConsumerData = _context.Consumerdata.ToList().Where(consumer => plantIds.Contains(consumer.IdPlant)).ToList();
               List<int> Consumerids= ConsumerData.ToList().Select(x => x.Id).ToList();
               BillData = _context.Bills.ToList().Where(bill => Consumerids.Contains(bill.IdConsumer)).ToList();

            }
            return BillData;
        }
    }
}
