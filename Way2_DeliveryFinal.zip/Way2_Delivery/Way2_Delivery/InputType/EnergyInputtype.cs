﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Way2_Delivery.Models;

namespace Way2_Delivery.InputType
{
    public class EnergyInputtype : ObjectGraphType<EnergyDataResponse>
    {
        public EnergyInputtype()
        {
            Field(x => x.powerSupplyId, type: typeof(StringGraphType)).Description("Id of the power distributor");
            Field(x => x.powerSupplyName, type: typeof(StringGraphType)).Description("Name of the power distributor.");
            Field(x => x.generatedCredits, type: typeof(DecimalGraphType)).Description("Generated Credits data.");
            Field(x => x.consumption, type: typeof(DecimalGraphType)).Description("Consumption property ");
            Field(x => x.balance, type: typeof(DecimalGraphType)).Description("Balance data");
            Field(x => x.credits, type: typeof(DecimalGraphType)).Description("Credits data");
            Field(x => x.cumulativeBalance, type: typeof(DecimalGraphType)).Description("CumulativeBalance data");
            Field(x => x.numberOfUcs, type: typeof(DecimalGraphType)).Description("numberOfUcs ");
            Field(x => x.timestamp, type: typeof(StringGraphType)).Description("energy generated date(with aggregative what should this field contain?)");

            
        }
    }
}