﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using Way2_Delivery.Repo;
using Way2_Delivery.InputType;

namespace Way2_Delivery
{
    public class GeneralQuery : ObjectGraphType
    {
        public GeneralQuery(IGeneralRepository repository)
        {
            Field<ListGraphType<EnergyInputtype>>("EnergyQuery",
            arguments: new QueryArguments(
            new QueryArgument<ListGraphType<NonNullGraphType<StringGraphType>>> { Name = "supplyIds" },
            new QueryArgument<StringGraphType> { Name = "startDate" },
            new QueryArgument<StringGraphType> { Name = "endDate" },
            new QueryArgument<StringGraphType> { Name = "interval" }
            ), resolve: context =>
    {
            List<String> idList = context.GetArgument<List<String>>("supplyIds");
            String startDate = context.GetArgument<String>("startDate");
            String endDate = context.GetArgument<String>("endDate");
            String interval = context.GetArgument<String>("interval");

            return repository.GetEnergyByFilters(idList, startDate, endDate,interval);
            });

            Field<ListGraphType<BillInputtype>>("BillingQuery",
           arguments: new QueryArguments(
           new QueryArgument<ListGraphType<NonNullGraphType<StringGraphType>>> { Name = "supplyIds" },
           new QueryArgument<StringGraphType> { Name = "startDate" },
           new QueryArgument<StringGraphType> { Name = "endDate" }
           ), resolve: context =>
           {
               List<String> idList = context.GetArgument<List<String>>("supplyIds");
               String startDate = context.GetArgument<String>("startDate");
               String endDate = context.GetArgument<String>("endDate");
               return repository.GetBillByFilters(idList, startDate, endDate);
           });
        }
    }
}
